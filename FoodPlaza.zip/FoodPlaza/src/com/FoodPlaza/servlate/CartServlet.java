package com.FoodPlaza.servlate;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.FoodPlaza.dao.CartDaoImpl;
import com.FoodPlaza.dao.OrderDaoImpl;
import com.FoodPlaza.pojo.Cart;
import com.FoodPlaza.pojo.Order;

/**
 * Servlet implementation class CartServlet
 */
@WebServlet("/CartServlet")
public class CartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	Cart c=new Cart();
	CartDaoImpl cd=new CartDaoImpl();
	RequestDispatcher rd;
	boolean flag=false;
	OrderDaoImpl od=new OrderDaoImpl();

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CartServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s = request.getSession();
		String operation=request.getParameter("action");

		String cname=(String)s.getAttribute("cname");



		if(operation!=null && operation.equals("AddToCart"))
		{
			int FoodId=Integer.parseInt(request.getParameter("FoodId"));

			//c.setCartId(FoodId);
			c.setEmailId(cname);
			c.setFoodId(FoodId);;
			c.setQuantity(1);

			flag=cd.addToCart(c);

			if(flag==true)
			{
				request.setAttribute("CartSucess", "Cart Added Sucessfully");
				rd=request.getRequestDispatcher("Index.jsp");
				rd.forward(request, response);
			}
			else
			{
				request.setAttribute("Error", "opps? something went wrong please try again");
				rd=request.getRequestDispatcher("Index.jsp");
				rd.forward(request, response);	
			}

		}
		else if(operation!=null && operation.equals("Delete")) 
		{

			int cid=Integer.parseInt(request.getParameter("cartId"));
			flag=cd.deleteCart(cid);
			if(flag== true)
			{
				response.sendRedirect("CartServlet");
			}
			else
			{
				request.setAttribute("Error", "opps? something went wrong please try again");
				rd=request.getRequestDispatcher("Index.jsp");
				rd.forward(request, response);	
			}
		}
		else if(operation!=null && operation.equals("showorder"))
		{
			
			List<Order> olist=od.showOrder();
			s.setAttribute("OrderList", olist);
			response.sendRedirect("OrderList.jsp");
			}
		else
		{
			List<Cart> clist=cd.showCart(cname);
			s.setAttribute("CartList", clist);
			response.sendRedirect("CartList.jsp");
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		double totalBil=0;
		HttpSession s = request.getSession();
		OrderDaoImpl od=new OrderDaoImpl();
		String cname=(String)s.getAttribute("cname");
		String price[]=request.getParameterValues("price");
		String qty[]=request.getParameterValues("Quantity");
		for(int i=0;i<price.length;i++)
		{
			totalBil=totalBil+Double.parseDouble(price[i])*Integer.parseInt(qty[i]);
		}
		int orderid=od.placeOrder(cname, totalBil);
		if(orderid>0)
		{
			flag=od.clearcart(cname);
			if(flag==true)
			{
				request.setAttribute("OrderSucess", "Congrats! Your Order is  Sucessfully Done  Your Bill Amount is="+totalBil);
				rd=request.getRequestDispatcher("Index.jsp");
				rd.forward(request, response); 
			}
			else
			{
				request.setAttribute("Error", "opps? something went wrong please try again");
				rd=request.getRequestDispatcher("Index.jsp");
				rd.forward(request, response);	
			}
		}
		else
		{
			request.setAttribute("Error", "opps? something went wrong please try again");
			rd=request.getRequestDispatcher("Index.jsp");
			rd.forward(request, response);	
		}



	}

}
