package com.FoodPlaza.pojo;

import java.io.InputStream;



public class Food {
int foodId;
String foodName,foodCategory;
double foodPrice;
InputStream foodImage;

public InputStream getFoodImage() {
	return foodImage;
}
public void setFoodImage(InputStream foodImage) {
	this.foodImage = foodImage;
}
public int getFoodId() {
	
	return foodId;
}
public void setFoodId(int foodId) {
	this.foodId = foodId;
}
public String getFoodName() {
	return foodName;
}
public void setFoodName(String foodName) {
	this.foodName = foodName;
}
public String getFoodCategory() {
	return foodCategory;
}
public void setFoodCategory(String foodCategory) {
	this.foodCategory = foodCategory;
}
public double getFoodPrice() {
	return foodPrice;
}
public void setFoodPrice(double foodPrice) {
	this.foodPrice = foodPrice;
}
@Override
public String toString() {
	return "Food [foodId=" + foodId + ", foodName=" + foodName + ", foodCategory=" + foodCategory + ", foodPrice="
			+ foodPrice + "]";
}

}
