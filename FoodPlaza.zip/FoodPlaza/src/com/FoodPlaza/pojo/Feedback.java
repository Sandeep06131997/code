package com.FoodPlaza.pojo;

public class Feedback {
	
	String Name;
	String EmailId;
	long ContectNo;
	String Comments;
	
	
	public String getName() {
		return Name;
	}


	public void setName(String name) {
		Name = name;
	}


	public String getEmailId() {
		return EmailId;
	}


	public void setEmailId(String emailId) {
		EmailId = emailId;
	}


	public long getContectNo() {
		return ContectNo;
	}


	public void setContectNo(long contectNo) {
		ContectNo = contectNo;
	}


	public String getComments() {
		return Comments;
	}


	public void setComments(String comments) {
		Comments = comments;
	}


	@Override
	public String toString() {
		return "Feedback [Name=" + Name + ", EmailId=" + EmailId + ", ContectNo=" + ContectNo + ", Comments=" + Comments
				+ "]";
	}
	
	

}
