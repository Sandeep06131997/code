package com.FoodPlaza.test;

import java.util.List;
import java.util.Scanner;

import com.FoodPlaza.dao.CustomerDaoImpl;
import com.FoodPlaza.pojo.Customer;
import com.FoodPlaza.pojo.Food;


public class CustomerTest {
	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {
		boolean result;
		Customer cu = new Customer();
		CustomerDaoImpl cd = new CustomerDaoImpl();
		System.out.println("1.Add Customer :-");
		System.out.println("2.Update Customer :-");
		System.out.println("3.Delete Customer :-");
		System.out.println("4.Display Customer :-");
		System.out.println("5.Search Customer :-");
		System.out.println("Enter choice :-");
		int ch =sc.nextInt();
		switch(ch)
		{
		case 1 :
			System.out.println("Enter Customer Name :-");
			String cname=sc.next();
			System.out.println("Enter Address");
			String address=sc.next();
			System.out.println("Enter ContactNo");
			String contactNo=sc.next();
			System.out.println("Enter EmailID");
			String emailId=sc.next();
			System.out.println("Enter Password");
			String password=sc.next();
			
			cu.setCustomerName(cname);
			cu.setAddress(address);
			cu.setContactNo(contactNo);
			cu.setEmailId(emailId);
			cu.setPassword(password);
			
			result=cd.addCustomer(cu);
			if(result==true)
			{
				System.out.println("FOOD ADDED SUCCESSFULLY");
			}
			else
			{
				System.out.println("not added");
			}
			break;
		
	case 2 :
		System.out.println("Enter Customer Id To Update :-");
		int id=sc.nextInt();
		System.out.println("Enter Customer Name To Update :-");
	 cname=sc.next();
		System.out.println("Enter AddressTo Update ");
 address=sc.next();
		System.out.println("Enter ContactNo To Update");
		contactNo=sc.next();
		System.out.println("Enter EmailID To Update ");
		 emailId=sc.next();
		System.out.println("Enter Password To Update ");
		 password=sc.next();
		
		 cu.setCustomerName(cname);
			cu.setAddress(address);
			cu.setContactNo(contactNo);
			cu.setEmailId(emailId);
			cu.setPassword(password);
			cu.setCustomerId(id);
			
		result =cd.updateCustomer(cu);
		if(result==true)
		{
			System.out.println("Customer UPDATED SUCCESSFULLY");
		}
		else
		{
			System.out.println("not updated");
		}
		break;
	case 3 :
		System.out.println("Enter Id To Delete :-");
		id=sc.nextInt();
		result=cd.deleteCustomer(id);
		if(result==true)
		{
			System.out.println("Customer DELETED SUCCESSFULLY");
		}
		else
		{
			System.out.println("not deleted");
		}
		
		break;
	case 4 :
		System.out.println("Customer details are :- ");
		List<Customer> clist=cd.displayCustomer();
		
		for(Customer c1:clist)
		{
			System.out.println(c1);
		}
		break;
	case 5 :
		System.out.println("Enter Customer Id :-");
		int customerId=sc.nextInt();
		cu = cd.searchCustomer(customerId);
		System.out.println(cu);
		
		break;

}
}
}
