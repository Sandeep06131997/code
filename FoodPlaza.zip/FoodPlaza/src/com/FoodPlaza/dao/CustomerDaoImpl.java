package com.FoodPlaza.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.FoodPlaza.pojo.Customer;
import com.FoodPlaza.pojo.Feedback;
import com.FoodPlaza.pojo.Food;
import com.FoodPlaza.utility.DatabaseConnection;

public class CustomerDaoImpl implements CustomerDao {

	
	Connection c;
	String sql;
	PreparedStatement ps;
	ResultSet rs;
	
	
	
	
	@Override
	public boolean addCustomer(Customer cu) {
		// TODO Auto-generated method stub
		try {
			c = DatabaseConnection.establishConnection();
			sql = "insert into Customer_21768(customerId,customerName,address,contactNo,emailId,password) values(?,?,?,?,?,?)";
			ps = c.prepareStatement(sql);
			ps.setInt(1, cu.getCustomerId());
			ps.setString(2, cu.getCustomerName());
			ps.setString(3, cu.getAddress());
			ps.setString(4, cu.getContactNo());
			ps.setString(5, cu.getEmailId());
			ps.setString(6, cu.getPassword());
			int x = ps.executeUpdate();
			if (x > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		
		
		
		return false;
	}

	@Override
	public boolean updateCustomer(Customer cu) {
		// TODO Auto-generated method stub
		
		try {
			c = DatabaseConnection.establishConnection();
			sql = "update Customer_21768 set customerName=?,address=?,contactNo=?,emailId=?,password=? where customerId=?";
			ps = c.prepareStatement(sql);
			ps.setString(1, cu.getCustomerName());
			ps.setString(2, cu.getAddress());
			ps.setString(3, cu.getContactNo());
			ps.setString(4, cu.getEmailId());
			ps.setString(5, cu.getPassword());
			
			ps.setInt(6, cu.getCustomerId());
			int x = ps.executeUpdate();
			if (x > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		
		return false;
	}

	@Override
	public boolean deleteCustomer(int customerId) {
		// TODO Auto-generated method stub
		
		try
		{
		
		c = DatabaseConnection.establishConnection();
		sql="delete from Customer_21768 where customerId=?";
		ps=c.prepareStatement(sql);
		ps.setInt(1,customerId);
		int x = ps.executeUpdate();
		if (x > 0) {
			return true;
		} else {
			return false;
		}
	} catch (Exception e) {
		e.printStackTrace();
	}
		
		
		return false;
	}

	@Override
	public List<Customer> displayCustomer() {
		// TODO Auto-generated method stub
		List<Customer> Customerlist = new ArrayList<Customer>();
		try
		{
			c = DatabaseConnection.establishConnection();
			sql="Select * from Customer_21768";
			ps=c.prepareStatement(sql);
			rs=ps.executeQuery();
			while(rs.next())
			{
				Customer cu = new Customer();
				cu.setCustomerId(rs.getInt("customerId"));
				cu.setCustomerName(rs.getString("customerName"));
				cu.setAddress(rs.getString("address"));
				cu.setContactNo(rs.getString("contactNo"));
				cu.setEmailId(rs.getString("emailId"));
				cu.setPassword(rs.getString("password"));
				
				
				
				Customerlist.add(cu);
				
			}
			return Customerlist;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		
		return null;
	}

	@Override
	public Customer searchCustomer(int customerId) {
		// TODO Auto-generated method stub
		
		
		Customer cu = new Customer();
		try
		{
			c = DatabaseConnection.establishConnection();
			sql="Select * from Customer_21768 where customerId=?";
			ps=c.prepareStatement(sql);

			ps.setInt(1,customerId);
			rs=ps.executeQuery();
			if(rs.next())
			{
				
				cu.setCustomerId(rs.getInt("customerId"));
				cu.setCustomerName(rs.getString("customerName"));
				cu.setAddress(rs.getString("address"));
				cu.setContactNo(rs.getString("contactNo"));
				cu.setEmailId(rs.getString("emailId"));
				cu.setPassword(rs.getString("password"));
			
				
			}
			return cu;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public Customer getCustomerByEmail(String email) {

		Customer cu = new Customer();
		try
		{
			c = DatabaseConnection.establishConnection();
			sql="Select * from Customer_21768 where emailId=?";
			ps=c.prepareStatement(sql);

			ps.setString(1,email);
			rs=ps.executeQuery();
			if(rs.next())
			{
				
				cu.setCustomerId(rs.getInt("customerId"));
				cu.setCustomerName(rs.getString("customerName"));
				cu.setAddress(rs.getString("address"));
				cu.setContactNo(rs.getString("contactNo"));
				cu.setEmailId(rs.getString("emailId"));
				cu.setPassword(rs.getString("password"));
			
				
			}
			return cu;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return null;
	}

	@Override
	public boolean AddFeedback(Feedback f) {
	
		
		try {
			c = DatabaseConnection.establishConnection();
			sql="insert into Feedback_21768 (Name,ContectNo,EmailId,Comments) values(?,?,?,?)";
			ps=c.prepareStatement(sql);
			ps.setString(1, f.getName());
			ps.setLong(2, f.getContectNo());
			ps.setString(3, f.getEmailId());
			ps.setString(4, f.getComments());
			int x=ps.executeUpdate();
			if(x>0)
			{
				return true;
			}
			else
			{
				return false;
			}
			
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}

	@Override
	public List<Feedback> ShowFeedback() {
		List<Feedback> feedbacklist = new ArrayList<Feedback>();

		try {
			c = DatabaseConnection.establishConnection();
			sql="Select * from Feedback_21768";
			ps=c.prepareStatement(sql);
			rs=ps.executeQuery();
			while(rs.next())
			{
				Feedback f=new Feedback();
				f.setName(rs.getString("Name"));
				f.setContectNo(rs.getLong("ContectNo"));
				f.setEmailId(rs.getString("EmailId"));
				f.setComments(rs.getString("Comments"));
				feedbacklist.add(f);
				
						
			}
			return feedbacklist;
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

}
