package com.FoodPlaza.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;




import com.FoodPlaza.pojo.Cart;
import com.FoodPlaza.pojo.Feedback;
import com.FoodPlaza.pojo.Order;
import com.FoodPlaza.utility.DatabaseConnection;

public class CartDaoImpl implements CartDao {
	int x=0;
	Connection c;
	String sql;
	PreparedStatement ps;
	ResultSet rs;

	@Override
	public boolean addToCart(Cart ca) {
		// TODO Auto-generated method stub
		try
		{
			c=DatabaseConnection.establishConnection();
			sql="insert into Cart_21768(foodId, emailId, quantity) values(?,?,?)";
			ps=c.prepareStatement(sql);
			
			ps.setInt(1, ca.getFoodId());
			ps.setString(2, ca.getEmailId());
			ps.setInt(3, ca.getQuantity());
			 x=ps.executeUpdate();
				
			if(x>0)
			{
				return true;
			}
			else 
			{
				return false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		

		

			
		return false;
	}

	@Override
	public List<Cart> showCart(String emailId) {
		// TODO Auto-generated method stub
		List<Cart> CartList=new ArrayList<Cart>();
		try
		{
			c=DatabaseConnection.establishConnection();
			sql="Select ca.cartId ,f.foodName, f.foodPrice, ca.quantity, ca.emailId from Food_21768 f inner join Cart_21768 ca where f.foodId=ca.foodId and ca.emailId=?";
			ps=c.prepareStatement(sql);
			ps.setString(1, emailId);
			rs= ps.executeQuery();
			while(rs.next())
			{
				Cart ca=new Cart();
				ca.setCartId(rs.getInt("CartId"));
				ca.setFoodName(rs.getString("foodName"));
				ca.setFoodPrice(rs.getDouble("foodPrice"));
				ca.setQuantity(rs.getInt("quantity"));
				ca.setEmailId(rs.getString("emailId"));

				CartList.add(ca);
			}
			return CartList;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public boolean deleteCart(int cartId) {
		// TODO Auto-generated method stub
		
		try
		{
			c=DatabaseConnection.establishConnection();
			sql="delete from Cart_21768 where cartId=?";
			ps=c.prepareStatement(sql);
			ps.setInt(1, cartId);
			int x=ps.executeUpdate();
			if(x>0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}
	



	


	@Override
	public List<Order> ShowOrder() 
	
	{
		List<Order> Orderlist = new ArrayList<Order>();
	
		
		try {
			c = DatabaseConnection.establishConnection();
			sql="Select * from Order_21768";
			ps=c.prepareStatement(sql);
			rs=ps.executeQuery();
			while(rs.next())
			{
				Order o=new Order();
				
				
						
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return null;
	}

}
