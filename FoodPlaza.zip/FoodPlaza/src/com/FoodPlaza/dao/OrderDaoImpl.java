package com.FoodPlaza.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.FoodPlaza.pojo.Food;
import com.FoodPlaza.pojo.Order;
import com.FoodPlaza.utility.DatabaseConnection;
public class OrderDaoImpl implements OrderDao
{

	Connection c;
	String sql;
	PreparedStatement ps;
	ResultSet rs;

	public boolean placeOrder(String emailId) {
		// TODO Auto-generated method stub
		double totalCost=0;
		String orderDate=new Date().toString();
		try
		{
			c=DatabaseConnection.establishConnection();
			sql="Select sum(f.foodPrice*ca.quantity) as totalBill from Food_21786 f inner join Cart_21786 ca where f.foodId=ca.foodId and ca.emailId=?";
			ps=c.prepareStatement(sql);
			ps.setString(1, emailId);
			rs=ps.executeQuery();
			if(rs.next())
			{
				totalCost=rs.getDouble("totalBill");
			}
			sql="insert into Order_21786(totalBill, emailId, orderDate) values(?,?,?)";
			ps=c.prepareStatement(sql);
			ps.setDouble(1, totalCost);
			ps.setString(2, emailId);
			ps.setString(3, orderDate);
			int x=ps.executeUpdate();
			if(x>0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		
		return false;
	}

	public List<Order> showOrder() {
		// TODO Auto-generated method stub
		
		List<Order> OrderList=new ArrayList<Order>();
		try
		{
			c=DatabaseConnection.establishConnection();
			sql="Select * from Order_21768";
			ps=c.prepareStatement(sql);
			rs= ps.executeQuery();
			while(rs.next())
			{
			Order oi=new Order();
			oi.setOrderId(rs.getInt("orderId"));
			oi.setEmailId(rs.getString("emailId"));
			oi.setTotalBill(rs.getDouble("tOtalBill"));
			oi.setOrderDate(rs.getString("orderDate"));
			
			OrderList.add(oi);
			}
			return OrderList;
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}

	@Override
	public int placeOrder(String emailId, double totalbill)
	
	{
		int ordereid;
	String orderDate=new Date().toString();
			
				try {
					c=DatabaseConnection.establishConnection();
					sql="insert into Order_21768(emailId,totalBill,orderDate) values(?,?,?)";
					ps=c.prepareStatement(sql);
					ps.setString(1, emailId);
					ps.setDouble(2, totalbill);
					ps.setString(3, orderDate);
					int x=ps.executeUpdate();
					if(x>0)
					{
						ps=c.prepareStatement("select orderid from Order_21768 where emailId=? and orderDate=?");
						ps.setString(1, emailId);
						ps.setString(2, orderDate);
						rs=ps.executeQuery();
						if(rs.next())
						{
						ordereid=rs.getInt("orderid");
						return ordereid;
						}
						else
						{
							return 0;
						}
					}
					else
					{
						return 0;
					}
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			
		return 0;
	}


	@Override
	public boolean clearcart(String emailId) {
		
		try {
			c=DatabaseConnection.establishConnection();
			sql="delete from Cart_21768 where emailId=?";
			ps=c.prepareStatement(sql);
			ps.setString(1, emailId);
			int x=ps.executeUpdate();
			if(x>0)
			{
				return true;
			}
			else
			{
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return false;
	}
	

}
