package com.FoodPlaza.dao;

import java.util.List;

import com.FoodPlaza.pojo.Cart;
import com.FoodPlaza.pojo.Feedback;
import com.FoodPlaza.pojo.Order;

public interface CartDao {
boolean addToCart(Cart ca);
List<Cart> showCart(String emailId);
boolean deleteCart(int cartId);
List<Order> ShowOrder();


}
