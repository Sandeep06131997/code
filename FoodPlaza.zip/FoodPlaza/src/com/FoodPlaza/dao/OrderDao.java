package com.FoodPlaza.dao;

import java.util.List;

import com.FoodPlaza.pojo.Order;

public interface OrderDao  {
	boolean placeOrder(String emailId);
	
	List<Order> showOrder();
	int placeOrder(String emailId,double totalbill);
	boolean clearcart(String emailId);
	

}
