package librarymanagment.servlet;

import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.librarymanagement.dao.BookDaoImp;
import com.librarymanagement.dao.StudentDaoImp;
import com.librarymanagements.pojo.Book;
import com.librarymanagements.pojo.Student;

/**
 * Servlet implementation class BookServlet
 */
@WebServlet("/BookServlet")
@MultipartConfig(maxFileSize=16777215)
public class BookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public BookServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BookDaoImp bdi = new BookDaoImp();
		HttpSession session=request.getSession();
		String operation= request.getParameter("operation");
		boolean flag=false;
		if(operation!=null && operation.equals("getBook"))
		{
			int book_id=Integer.parseInt(request.getParameter("book_id"));
			Book b=bdi.getBookById(book_id);
			session.setAttribute("book", b);
			response.sendRedirect("UpdateBook.jsp");
		}
		else if(operation!=null&&operation.equals("deleteBook"))
		{
			int book_id=Integer.parseInt(request.getParameter("book_id"));
			flag=bdi.deleteBookById(book_id);
			
			if(flag==true)
			{
				List <Book> blist = bdi.displayAllBooks();
				session.setAttribute("bookList", blist);
				response.sendRedirect("BookList.jsp");
			}
			else
			{
				response.sendRedirect("UpdateBook.jsp");
			}
		}
		else
		{
			List <Book> blist = bdi.displayAllBooks();
			session.setAttribute("bookList", blist);
			response.sendRedirect("BookList.jsp");
	}
		}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		Book b=new Book();
		BookDaoImp bdi= new BookDaoImp();
		HttpSession session=request.getSession();
		String operation= request.getParameter("operation");
	boolean flag;
		
		if(operation!=null&& operation.equals("AddBook"))
		{
			
			String book_name=request.getParameter("book_name");
			String author_name=request.getParameter("author_name");
			String publisher=request.getParameter("publisher");
			String categary=request.getParameter("categary");
			int quantity_avail=Integer.parseInt(request.getParameter("quantity_avail"));

			Part getPart=request.getPart("Book_Image");
			InputStream is=getPart.getInputStream();
			
	
	
			
		
			b.setBook_name(book_name);
			b.setAuthor(author_name);
			b.setPublisher(publisher);
			b.setCategory(categary);
			b.setQuantity_avail(quantity_avail);
			b.setBook_Image(is);
	
			flag=bdi.addBook(b);
	
	
		
			if(flag)
			{
		//response.sendRedirect("success.html");
				List <Book> blist = bdi.displayAllBooks();
				session.setAttribute("bookList", blist);
				response.sendRedirect("BookList.jsp");
		
			}
			else
			{
				response.sendRedirect("AddBook.jsp");
			}
		}
	
		else if(operation!=null&& operation.equals("UpdateBook"))
		{

			int book_id=Integer.parseInt(request.getParameter("book_id"));
			
		
			String book_name=request.getParameter("book_name");
			String author_name=request.getParameter("author_name");
			String Publisher=request.getParameter("publisher");
			String Categary=request.getParameter("categary");
			int quantity_avail=Integer.parseInt(request.getParameter("quantity_avail"));
			
			Part getPart=request.getPart("Book_Image");
			InputStream is=getPart.getInputStream();
			
			
			
			b.setBook_id(book_id);
			b.setBook_name(book_name);
			b.setAuthor(author_name);
			b.setPublisher(Publisher);
			b.setCategory(Categary);
			b.setQuantity_avail(quantity_avail);
			
			if(getPart.getSize()==0)
			{
				Book bk=(Book)session.getAttribute("book");
				is=bk.getBook_Image();
				b.setBook_Image(is);
			}
			else
			{
				b.setBook_Image(is);
				
			}
			b.setBook_id(book_id);
			
			flag=bdi.updateBook(b);
			System.out.println(flag);

			if(flag)
			{
				List <Book> blist = bdi.displayAllBooks();
				session.setAttribute("bookList", blist);
				response.sendRedirect("BookList.jsp");
			}
			else
			{
				response.sendRedirect("UpdateBook.jsp");
			}
		}
		
	}

}
