package librarymanagment.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.librarymanagement.dao.BookDaoImp;
import com.librarymanagements.pojo.Book;

/**
 * Servlet implementation class AddBookServlet
 */
@WebServlet("/AddBookServlet")
public class AddBookServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddBookServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		BookDaoImp bdi = new BookDaoImp();
		HttpSession session=request.getSession();
		String operation= request.getParameter("operation");
		if(operation!=null&&operation.equals("getBook"))
		{
			int bookId=Integer.parseInt(request.getParameter("bookId"));
			Book b=bdi.getBookById(bookId);
			session.setAttribute("book", b);
			response.sendRedirect("UpdateBook.jsp");
		}
		else
		{
			List <Book> blist = bdi.displayAllBooks();
			session.setAttribute("bookList", blist);
			response.sendRedirect("BookList.jsp");
		}
	}
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		boolean flag;
		Book b = new Book();
		BookDaoImp bdi=new BookDaoImp();
		HttpSession session=request.getSession();
		String operation=request.getParameter("operation");
		if(operation!=null&&operation.equals("AddBook"))
		{
			String bookName=request.getParameter("bookName");
			String bookAuthor=request.getParameter("bookAuthor");
			String bookPublisher=request.getParameter("bookPublisher");
			String bookCategory=request.getParameter("bookCategory");
			int bookQuantity=Integer.parseInt(request.getParameter("bookQuantity"));
			
			b.setBook_name(bookName);
			b.setAuthor(bookAuthor);
			b.setPublisher(bookPublisher);
			b.setCategory(bookCategory);
			b.setQuantity_avail(bookQuantity);

			flag=bdi.addBook(b);

			if(flag)
			{
				List <Book> blist = bdi.displayAllBooks();
				session.setAttribute("bookList", blist);
				response.sendRedirect("BookList.jsp");
			}
			else
			{
				response.sendRedirect("AddBook.jsp");
			}
		}
		else if(operation.equals("UpdateBook"))
		{
			String bookName=request.getParameter("bookName");
			String bookAuthor=request.getParameter("bookAuthor");
			String bookPublisher=request.getParameter("bookPublisher");
			String bookCategory=request.getParameter("bookCategory");
			int bookQuantity=Integer.parseInt(request.getParameter("bookQuantity"));
			int bookId=Integer.parseInt(request.getParameter("bookId"));

			b.setBook_id(bookId);
			b.setAuthor(bookAuthor);
			b.setPublisher(bookPublisher);
			b.setCategory(bookCategory);
			b.setQuantity_avail(bookQuantity);
			b.setBook_id(bookId);

			flag=bdi.updateBook(b);

			if(flag)
			{
				List <Book> blist = bdi.displayAllBooks();
				session.setAttribute("bookList", blist);
				response.sendRedirect("BookList.jsp");
			}
			else
			{
				response.sendRedirect("UpdateBook.jsp");
			}
		}
	}

	}


