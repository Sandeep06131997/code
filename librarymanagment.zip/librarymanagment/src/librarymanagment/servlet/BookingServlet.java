package librarymanagment.servlet;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.librarymanagement.dao.IssueBookDaoImp;
import com.librarymanagements.pojo.IssuedBook;

/**
 * Servlet implementation class BookingServlet
 */
@WebServlet("/BookingServlet")
public class BookingServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public BookingServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		String operation=request.getParameter("operation");
		HttpSession session=request.getSession();
		IssueBookDaoImp bdi=new IssueBookDaoImp();
		
		if(operation!=null && operation.equals("issueBook"))
		{
			int bookid=Integer.parseInt(request.getParameter("bookid"));
			
			String u_email=(String)session.getAttribute("User");
			LocalDate today=LocalDate.now();
			LocalDate returndate=today.plusDays(10);
			
			IssuedBook ib=new IssuedBook();
			ib.setBook_id(bookid);
			ib.setU_email(u_email);			
			ib.setIssuedate(today);
			ib.setExpectedreturn(returndate);

			
			boolean flag=bdi.IssuedBook(ib);
			if(flag)
			{
				request.setAttribute("success", "book Issued!! please return the book by "+returndate);
				RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
				rd.forward(request, response);
			}
			
		}
		if(operation!=null && operation.equals("overdue"))
		{
			List<IssuedBook> iblist=bdi.getOverdue();
			session.setAttribute("overduelist", iblist);
			RequestDispatcher rd=request.getRequestDispatcher("Overdue.jsp");
			rd.forward(request, response);
		}
		if(operation!=null && operation.equals("userRecord"))
		{
			
			String u_email=request.getParameter("u_email");
			if(u_email==null)
				u_email=(String)session.getAttribute("User");
			System.out.println(u_email);
			List<IssuedBook> iblist=bdi.getrecordofUser(u_email);
			System.out.println(iblist);
			session.setAttribute("useroverdue", iblist);
			
			RequestDispatcher rd=request.getRequestDispatcher("Records.jsp");
			rd.forward(request, response);
		}
		if(operation!=null && operation.equals("returnBook"))
		{
			int u_id=Integer.parseInt(request.getParameter("u_id"));
			int bookid=Integer.parseInt(request.getParameter("bookid"));
			boolean flag=bdi.returnBook(u_id, bookid);
			if(flag)
			{
				request.setAttribute("success", "Book returned");
				
				List<IssuedBook> iblist=bdi.getrecordofUser((String)session.getAttribute("User"));
				System.out.println(iblist);
				session.setAttribute("useroverdue", iblist);
				RequestDispatcher rd=request.getRequestDispatcher("/BookingServlet?operation=userRecord");
				rd.forward(request, response);
			}
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
