package librarymanagment.servlet;

import java.io.IOException;
import java.util.List;

import javax.net.ssl.SSLSession;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.librarymanagement.dao.StudentDaoImp;
//import com.librarymanagements.pojo.Book;
import com.librarymanagements.pojo.Student;

/**
 * Servlet implementation class CustomerServlet
 */
@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public StudentServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		StudentDaoImp sbdi=new StudentDaoImp();
		HttpSession session=request.getSession();
		String operation= request.getParameter("operation");
		boolean flag=false;
		if(operation!=null && operation.equals("getStudent"))
		{
			//int s_id=Integer.parseInt(request.getParameter("s_id"));
			String email_id=(String)session.getAttribute("User");
			//Student s=sbdi.getStudentByid(s_id);
			Student s=sbdi.getStudentByemail_id(email_id);
			session.setAttribute("Student", s);

			response.sendRedirect("UpdateStudent.jsp");
		}
		else if(operation!=null&&operation.equals("deleteStudent"))
		{
			int s_id=Integer.parseInt(request.getParameter("s_id"));
			flag=sbdi.deleteStudentById(s_id);

			if(flag==true)
			{
				List <Student> slist = sbdi.displayAllStudent();
				session.setAttribute("Studentlist", slist);
				response.sendRedirect("StudentList.jsp");
			}
			else
			{
				response.sendRedirect("UpdateStudent.jsp");
			}
		}
		else
		{
			List<Student> slist = sbdi.displayAllStudent();
			session.setAttribute("Studentlist", slist);
			response.sendRedirect("StudentList.jsp");
		}
	}


	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Student s=new Student();
		StudentDaoImp sbdi= new StudentDaoImp();
		HttpSession session=request.getSession();
		String operation= request.getParameter("operation");
		boolean flag;


		if(operation!=null && operation.equals("Student"))
		{
			String s_name=request.getParameter("s_name");
			String email_id  =request.getParameter("email_id");
			String password=request.getParameter("password");
			String branch=request.getParameter("branch");
			String year=request.getParameter("year");



			s.setS_name(s_name);
			s.setEmail_id(email_id);
			s.setPassword(password);
			s.setBranch(branch);
			s.setYear(year);

			System.out.println(s);
			flag=sbdi.addStudent(s);
			if(flag)
			{
				//response.sendRedirect("SuccessStudent.html");
				List <Student> slist = sbdi.displayAllStudent();
				session.setAttribute("Studentlist", slist);
				response.sendRedirect("StudentList.jsp");

			}
			else
			{
				response.sendRedirect("Student.jsp");
			}

		}

		else if(operation!=null &&operation.equals("UpdateStudent"))
		{
			int s_id=Integer.parseInt(request.getParameter("s_id"));
			String s_name=request.getParameter("s_name");
			String email_id=request.getParameter("email_id");

			String password=request.getParameter("password");
			String branch=request.getParameter("branch");
			String year=request.getParameter("year");


			s.setS_id(s_id);
			s.setS_name(s_name);
			s.setEmail_id(email_id);			
			s.setPassword(password);
			s.setBranch(branch);
			s.setYear(year);


			flag=sbdi.updateStudent(s);

			if(flag)
			{
				List <Student> slist = sbdi.displayAllStudent();
				session.setAttribute("Studentlist", slist);
				response.sendRedirect("StudentList.jsp");
			}
			else
			{
				response.sendRedirect("UpdateStudent.jsp");
			}
		}
	}
}



