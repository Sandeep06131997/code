package librarymanagment.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.librarymanagement.dao.LoginDaoImp;


@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public LoginServlet() {
        super();
        
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		session.invalidate();
		response.sendRedirect("index.jsp");
		
	
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		boolean flag;
		LoginDaoImp ldi=new LoginDaoImp();
		String operation=request.getParameter("operation");
		HttpSession session=request.getSession();
		if(operation!=null && operation.equals("LoginPage"))
		{
			String type=request.getParameter("type");
			String name=request.getParameter("uname");
			String password=request.getParameter("pass");
			
			if(type.equals("student"))
			{
				flag=ldi.StudentLogin(name, password);
				if(flag)
				{
					session.setAttribute("User", name);
					request.setAttribute("Success", "Welcome "+name);
					RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
					rd.forward(request, response);
				}
				else
				{
					session.setAttribute("Failure", "Login Failed! Try again.");
					RequestDispatcher rd=request.getRequestDispatcher("LoginPage.jsp");
					rd.forward(request, response);
				}
			}
			else if(type.equals("admin"))
			{
				flag=ldi.AdminLogin(name, password);
				if(flag)
				{
					session.setAttribute("Admin", name);
					request.setAttribute("Success", "Welcome "+name);
					RequestDispatcher rd=request.getRequestDispatcher("index.jsp");
					rd.forward(request, response);
				}
				else
				{
					session.setAttribute("Failure", "Login Failed! Try again.");
					RequestDispatcher rd=request.getRequestDispatcher("LoginPage.jsp");
					rd.forward(request, response);
				}
			}
		}
		else if(operation!=null && operation.equals("changepassword"))
		{
			String name=request.getParameter("name");
			String password=request.getParameter("Oldpassword");
			String newpassword=request.getParameter("Newpassword");
			
			flag=ldi.AdminLogin(name,password);
			if(flag)
			{
				flag=ldi.ChangePassword(name, newpassword);
				if(flag)
				{
					request.setAttribute("Success", "Changed successfully. Login with new password. "+name);
					RequestDispatcher rd=request.getRequestDispatcher("LoginPage.jsp");
					rd.forward(request, response);
				}
				else
				{
					session.setAttribute("Failure", "Changes Failed! Try again.");
					RequestDispatcher rd=request.getRequestDispatcher("ChangePassword.jsp");
					rd.forward(request, response);
				}
			}
			else
			{
				session.setAttribute("Failure", "Login Failed! Try again.");
				RequestDispatcher rd=request.getRequestDispatcher("ChangePassword.jsp");
				rd.forward(request, response);
			}
		}
	}
	}


