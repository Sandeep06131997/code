package com.librarymanagement.dao;
import java.util.List;

import com.librarymanagements.pojo.IssuedBook;

public interface IssueBookDao
{
boolean IssuedBook(IssuedBook i);
boolean returnBook(int u_id, int book_id);

int getBookQnt( int Book_id);
boolean updateCount(int Book_id,int count);

List<IssuedBook>getOverdue();
List<IssuedBook>getrecordofUser(String email);

}
