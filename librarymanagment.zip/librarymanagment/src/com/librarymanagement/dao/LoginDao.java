package com.librarymanagement.dao;

public interface LoginDao 
{
boolean AdminLogin(String uname,String pass);
boolean StudentLogin(String uname,String pass);
boolean ChangePassword(String name,String newpassword);
}
