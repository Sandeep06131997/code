package com.librarymanagement.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.librarymanagement.utility.DB1Utility;
import com.librarymanagement.utility.DBUtility;
import com.librarymanagements.pojo.IssuedBook;

public class IssueBookDaoImp implements IssueBookDao
{

	String sql;
	Connection con;
	ResultSet rs;
	PreparedStatement ps;
	boolean flag;
	int rows;
	@Override
	public boolean IssuedBook(IssuedBook i) 
	{
		try 
		{
			con=DBUtility.getDBConnect();
			int count=getBookQnt(i.getBook_id());
			if(count>0)
			{
				sql="insert into IssueBook (u_email ,bookid ,issuedate ,expectedreturn)value(?,?,?,?)";
				ps=con.prepareStatement(sql);
				ps.setString(1,i.getU_email());
				ps.setInt(2,i.getBook_id());
				ps.setDate(3, Date.valueOf(i.getIssuedate()));
				ps.setDate(4, Date.valueOf(i.getExpectedreturn()));

				int rows=ps.executeUpdate();
				if(rows>0) 
				{
					flag=updateCount(i.getBook_id(),count-1);
				}
				else 
				{
					flag=false;
				}
			}
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return flag;
	}



	@Override
	public boolean returnBook(int u_id,int bookid)
	{
		try 
		{
			con=DBUtility.getDBConnect();
			LocalDate today=LocalDate.now();
			sql="update IssueBook set actualreturn =? where u_id=?";
			ps=con.prepareStatement(sql);			
			ps.setDate(1, Date.valueOf(today));
			ps.setInt(2, u_id);
	
			rows=ps.executeUpdate();

			if(rows>0)
			{
				int count=getBookQnt(bookid);
				flag=updateCount(bookid,count+1);
			}
			else
				flag=false;
			con.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return flag;
	}
	@Override
	public List<IssuedBook> getOverdue()
	{
		List<IssuedBook> ilist=new ArrayList<>();
		try 
		{
			con=DBUtility.getDBConnect();
			LocalDate today=LocalDate.now();
			sql="select  u_email,count(bookid) from IssueBook  where actualreturn is null group by u_email";
			ps=con.prepareStatement(sql);			
			//ps.setDate(1, Date.valueOf(today));
			rs=ps.executeQuery();
			while(rs.next())
			{
				IssuedBook i=new IssuedBook();
				//i.setUid(rs.getInt(1));
				i.setU_email(rs.getString(1));
				/*i.setBook_id(rs.getInt(3));
				i.setIssuedate(rs.getDate(4).toLocalDate());
				i.setExpectedreturn(rs.getDate(5).toLocalDate());*/
				i.setCoun(rs.getInt(2));;
				ilist.add(i);
			}
			//con.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return ilist;
	}
	@Override
	public List<IssuedBook> getrecordofUser(String u_email)
	{

		List<IssuedBook> ilist=new ArrayList<>();
		try 
		{
			con=DBUtility.getDBConnect();
			sql="select u_id,book_name,bookid, issuedate ,expectedreturn from IssueBook as i inner join Book_id as b on book_id=bookid where u_email=? and actualreturn is null ";
			ps=con.prepareStatement(sql);			
			ps.setString(1, u_email);
			System.out.println(ps);
			rs=ps.executeQuery();
			while(rs.next())
			{
				IssuedBook i=new IssuedBook();
				i.setU_id(rs.getInt(1));
				i.setBook_name(rs.getString(2));
				i.setBook_id(rs.getInt(3));
				i.setIssuedate(rs.getDate(4).toLocalDate());
				i.setExpectedreturn(rs.getDate(5).toLocalDate());
				
				ilist.add(i);
			}
			con.close();
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return ilist;
		
	}



	@Override
	public int getBookQnt(int Book_id) 
	{
		int count=0;
		try {
			
			con=DB1Utility.getDBConnect();
			sql="select quantity_avail from Book_id where book_id=?";

			ps=con.prepareStatement(sql);

			ps.setInt(1, Book_id);
			rs=ps.executeQuery();
			if(rs.next())
			count=rs.getInt(1);
			else
				count=0;
			//con.close();
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return count;
	}



	@Override
	public boolean updateCount(int Book_id, int count) 
	{
		try 
		{
			con=DBUtility.getDBConnect();

			sql="update Book_id set quantity_avail=? where book_id=?";
			ps=con.prepareStatement(sql);
			ps.setInt(1, count);
			ps.setInt(2, Book_id);
			rows=ps.executeUpdate();
			if(rows>0)
				flag=true;
			else
				flag=false;
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return flag;
	

		
		
	}



	



	






}
