package com.librarymanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.librarymanagement.utility.DBUtility;
import com.librarymanagements.pojo.Student;




public class StudentDaoImp implements StudentDao
{
	String sql;
	Connection con;
	ResultSet rs;
	PreparedStatement ps;
	boolean flag;
	int rows;
	@Override
	public boolean addStudent(Student s) {
		try 
		{


			con=DBUtility.getDBConnect();
			sql="insert into Student (s_name,email_id,password,branch,year)values(?,?,?,?,?)";
			ps=con.prepareStatement(sql);
			ps.setString(1, s.getS_name());
			ps.setString(2, s.getEmail_id());
			ps.setString(3, s.getPassword());
			ps.setString(4,s.getBranch());
			ps.setString(5, s.getYear());
			int rows=ps.executeUpdate();
			if(rows>0) 
			{
				flag=true;
			}
			else 
			{
				flag=false;
			}
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return flag;
	}
		
	
	@Override
	public boolean updateStudent(Student s)
	{
		try 
		{


			con=DBUtility.getDBConnect();
			sql="update  Student set  s_name=?,email_id=?,password=?,branch=?,year=? where s_id=?";
			ps=con.prepareStatement(sql);
			ps.setString(1, s.getS_name());
			ps.setString(2, s.getEmail_id());
			ps.setString(3, s.getPassword());
			ps.setString(4,s.getBranch());
			ps.setString(5, s.getYear());
			ps.setInt(6, s.getS_id());
			int rows=ps.executeUpdate();
			if(rows>0) 
			{
				flag=true;
			}
			else 
			{
				flag=false;
			}
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return flag;
	}
	@Override
	public boolean deleteStudentById(int s_id) 
	{
		try 
		{

			con=DBUtility.getDBConnect();
			sql="delete from Student  where s_id=?";

			ps=con.prepareStatement(sql);
			ps.setInt(1, s_id);
			int rows=ps.executeUpdate();
			if(rows>0) 
			{
				flag=true;
			}
			else 
			{
				flag=false;
			}
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag;
	
	}
	/*@Override
	public Student getStudentByid(int s_id)	
	{
		Student s=new Student();

		try
		{
			
			con=DBUtility.getDBConnect();
			sql="select * from Student where s_id=? ";
			ps=con.prepareStatement(sql);
			ps.setInt(1,s_id);
			rs=ps.executeQuery();
			while(rs.next())
			{
				
				s.setS_id(rs.getInt(1));
				s.setS_name(rs.getString(2));
				s.setEmail_id(rs.getString(3));
				s.setPassword(rs.getString(4));
				s.setBranch(rs.getString(5));
				s.setYear(rs.getString(6));

			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return s;
	}*/
	@Override
	public List<Student> displayAllStudent()
	{
		List<Student>slist=new ArrayList<>();
		try
		{
			con=DBUtility.getDBConnect();
			sql="select *  from Student ";
			ps=con.prepareStatement(sql);

			rs=ps.executeQuery();


			while(rs.next())
			{
				Student s=new Student();
				s.setS_id(rs.getInt(1));
				s.setS_name(rs.getString(2));
				s.setEmail_id(rs.getString(3));
				s.setPassword(rs.getString(4));
				s.setBranch(rs.getString(5));
				s.setYear(rs.getString(6));
				slist.add(s);

			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();

		}
		return slist;
		
	}


	@Override
	public  Student getStudentByemail_id(String email_id)
	{
		Student s=new Student();

		try
		{
			
			con=DBUtility.getDBConnect();
			sql="select * from Student where email_id=? ";
			ps=con.prepareStatement(sql);
			ps.setString(1,email_id);
			rs=ps.executeQuery();
			while(rs.next())
			{
				
				s.setS_id(rs.getInt(1));
				s.setS_name(rs.getString(2));
				s.setEmail_id(rs.getString(3));
				s.setPassword(rs.getString(4));
				s.setBranch(rs.getString(5));
				s.setYear(rs.getString(6));

			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return s;
	}


	
}
