package com.librarymanagement.dao;



	import java.sql.Connection;
	import java.sql.PreparedStatement;
	import java.sql.ResultSet;
	import java.sql.SQLException;

	import com.librarymanagement.utility.DBUtility;

	public class LoginDaoImp implements LoginDao
	{
		String sql;
		Connection con;
		ResultSet rs;
		PreparedStatement ps;
		boolean flag;
		@Override
		public boolean AdminLogin(String uname, String pass) 
		{
			try {
				con=DBUtility.getDBConnect();
				sql="select * from Admin where AdminName=? and AdminPassword=?";
				
					ps=con.prepareStatement(sql);
					ps.setString(1, uname);
					ps.setString(2, pass);
					rs=ps.executeQuery();
					if(rs.next())
					{
						flag=true;
					}
					else
					{
						flag=false;
					}
				} 
				catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				return flag;
			}

		
		@Override
		public boolean StudentLogin(String uname, String pass)
		{
			try {
				con=DBUtility.getDBConnect();
				sql="select * from Student where email_id=? and password =?";
				
				
						ps=con.prepareStatement(sql);
						ps.setString(1, uname);
						ps.setString(2, pass);
						System.out.println(ps);
						rs=ps.executeQuery();
						if(rs.next())
						{
							flag=true;
						}
						else
						{
							flag=false;
						}
				}
					
					catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				System.out.println(flag);
			return flag;
		}
		@Override
		public boolean ChangePassword(String name, String  newpassword)
		{
			try {
				con=DBUtility.getDBConnect();
			String	sql="update Admin set  AdminPassword=? where AdminName=?";
				
				
						ps=con.prepareStatement(sql);
						ps.setString(2, name);
						ps.setString(1, newpassword);
						System.out.println(ps);
					int	row=ps.executeUpdate();
						if(row>0)
						{
							flag=true;
						}
						else
						{
							flag=false;
						}
				}
					
					catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				System.out.println(flag);
			return flag;
		}
		
		
	}

