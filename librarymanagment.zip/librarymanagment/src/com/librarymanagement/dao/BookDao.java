package com.librarymanagement.dao;

import java.util.List;

import com.librarymanagements.pojo.Book;

public interface BookDao
{
	

	boolean addBook(Book b);
	boolean updateBook(Book b);
	boolean deleteBookById(int book_id);

	Book getBookById(int book_id);	
		List<Book>displayAllBooks();
		
		
	}

	

