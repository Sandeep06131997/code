package com.librarymanagement.dao;

import java.util.List;

import com.librarymanagements.pojo.Student;



public interface StudentDao 
{

	boolean addStudent(Student s);
	boolean updateStudent(Student s);
	boolean deleteStudentById(int s_id);
	// getStudentByemail_id(Student s);
	Student getStudentByemail_id(String email_id);	
		List<Student>displayAllStudent();
		
}
