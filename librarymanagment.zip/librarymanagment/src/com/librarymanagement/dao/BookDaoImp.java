package com.librarymanagement.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.librarymanagement.utility.DBUtility;
import com.librarymanagements.pojo.Book;

public class BookDaoImp implements BookDao 
{
	String sql;
	Connection con;
	ResultSet rs;
	PreparedStatement ps;
	boolean flag;
	int rows;
	@Override
	public boolean addBook(Book b)
	{
		try 
		{


			con=DBUtility.getDBConnect();
			sql="insert into Book_id (book_name,author_name,publisher,categary,quantity_avail,Book_image)values(?,?,?,?,?,?)";
			ps=con.prepareStatement(sql);
			ps.setString(1, b.getBook_name());
			ps.setString(2, b.getAuthor());
			ps.setString(3, b.getPublisher());
			ps.setString(4,b.getCategory());

			ps.setInt(5, b.getQuantity_avail());
			ps.setBlob(6, b.getBook_Image());
			int rows=ps.executeUpdate();
			if(rows>0) 
			{
				flag=true;
			}
			else 
			{
				flag=false;
			}
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return flag;
	}

	@Override
	public boolean updateBook(Book b)
	{
		try 
	{

		con=DBUtility.getDBConnect();
		sql="update Book_id set book_name=?,author_name=?,publisher=?,categary=?,quantity_avail=?,Book_Image=? where book_id=?";

		ps=con.prepareStatement(sql);

		ps.setString(1, b.getBook_name());
		ps.setString(2, b.getAuthor());
		ps.setString(3, b.getPublisher());
		ps.setString(4,b.getCategory());

		ps.setInt(5, b.getQuantity_avail());
		
		ps.setBlob(6, b.getBook_Image());
		ps.setInt(7, b.getBook_id());
		
		int rows=ps.executeUpdate();
		if(rows>0) 
		{
			flag=true;
		}
		else 
		{
			flag=false;
		}
	}
	catch (SQLException e)
	{
		// TODO Auto-generated catch block
		e.printStackTrace();
	}

	return flag;
	}

	@Override
	public boolean deleteBookById(int book_id)
	{
		try 
		{

			con=DBUtility.getDBConnect();
			sql="delete from Book_id  where book_id=?";

			ps=con.prepareStatement(sql);
			ps.setInt(1, book_id);
			int rows=ps.executeUpdate();
			if(rows>0) 
			{
				flag=true;
			}
			else 
			{
				flag=false;
			}
		}
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		return flag;
	}

	@Override
	public Book getBookById(int book_id) {
		Book b=new Book();

		try
		{
			
			con=DBUtility.getDBConnect();
			sql="select * from Book_id where book_id=? ";
			ps=con.prepareStatement(sql);
			ps.setInt(1,book_id);
			rs=ps.executeQuery();
			while(rs.next())
			{
				
				b.setBook_id(rs.getInt(1));
				b.setBook_name(rs.getString(2));
				b.setAuthor(rs.getString(3));
				b.setPublisher(rs.getString(4));
				b.setCategory(rs.getString(5));
				b.setQuantity_avail(rs.getInt(6));
				b.setBook_Image(rs.getBinaryStream(7));
				

			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}

		return b;

		
	}

	@Override
	public List<Book> displayAllBooks() {
		List<Book>blist=new ArrayList<>();
		try
		{
			con=DBUtility.getDBConnect();
			sql="select * from Book_id ";
			ps=con.prepareStatement(sql);

			rs=ps.executeQuery();


			while(rs.next())
			{
				Book b=new Book();
				b.setBook_id(rs.getInt(1));
				b.setBook_name(rs.getString(2));
				b.setAuthor(rs.getString(3));
				b.setPublisher(rs.getString(4));
				b.setCategory(rs.getString(5));
				b.setQuantity_avail(rs.getInt(6));
				b.setBook_Image(rs.getBinaryStream(7));
				blist.add(b);

			}
		}
		catch(SQLException e)
		{
			e.printStackTrace();

		}
		return blist;
	}







}






