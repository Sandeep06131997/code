package com.librarymanagements.pojo;

public class Student 
{
private int s_id;
private String s_name, email_id, password, branch,year;
@Override
public String toString() {
	return "Student [s_id=" + s_id + ", s_name=" + s_name + ", email_id=" + email_id + ", password=" + password
			+ ", branch=" + branch + ", year=" + year + "]";
}
public int getS_id() {
	return s_id;
}
public void setS_id(int s_id) {
	this.s_id = s_id;
}
public String getS_name() {
	return s_name;
}
public void setS_name(String s_name) {
	this.s_name = s_name;
}
public String getEmail_id() {
	return email_id;
}
public void setEmail_id(String email_id) {
	this.email_id = email_id;
}
public String getPassword() {
	return password;
}
public void setPassword(String password) {
	this.password = password;
}
public String getBranch() {
	return branch;
}
public void setBranch(String branch) {
	this.branch = branch;
}

public String getYear() {
	return year;
}
public void setYear(String year){
	this.year=year;
}

}
