package com.librarymanagements.pojo;

import java.io.InputStream;

public class Book {

	private int book_id,quantity_avail;
	private String book_name,author,publisher,category;
	private InputStream Book_Image;
	
	public InputStream getBook_Image() {
		return Book_Image;
	}
	public void setBook_Image(InputStream book_Image) {
		Book_Image = book_Image;
	}
	@Override
	public String toString() {
		return "Book [book_id=" + book_id + ", quantity_avail=" + quantity_avail + ", book_name=" + book_name
				+ ", author=" + author + ", publisher=" + publisher + ", category=" + category + "]";
	}
	public int getBook_id() {
		return book_id;
	}
	public void setBook_id(int book_id) {
		this.book_id = book_id;
	}
	public int getQuantity_avail() {
		return quantity_avail;
	}
	public void setQuantity_avail(int quantity_avail) {
		this.quantity_avail = quantity_avail;
	}
	public String getBook_name() {
		return book_name;
	}
	public void setBook_name(String book_name) {
		this.book_name = book_name;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	
	public String getPublisher() {
		return publisher;
	}
	public void setPublisher(String publisher) {
		this.publisher = publisher;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}

}

