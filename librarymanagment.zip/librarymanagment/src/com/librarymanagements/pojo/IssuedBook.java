package com.librarymanagements.pojo;

import java.time.LocalDate;

public class IssuedBook 
{
int u_id,book_id,count;
String u_email,book_name;
LocalDate issuedate,expectedreturn,actualreturn;
@Override
public String toString() {
	return "IssueBook [u_id=" + u_id + ", book_id=" + book_id + ", Book_name=" +book_name+", u_email=" + u_email + ", issuedate=" + issuedate
			+ ", expectedreturn=" + expectedreturn + ", actualreturn=" + actualreturn + "]";
}

public int getU_id() {
	return u_id;
}

public int getCount() {
	return count;
}

public void setCoun(int count) {
	this.count = count;
}

public void setU_id(int u_id) {
	this.u_id = u_id;
}

public String getU_email() {
	return u_email;
}
public void setU_email(String u_email) {
	this.u_email = u_email;
}
public LocalDate getIssuedate() {
	return issuedate;
}

public void setIssuedate(LocalDate issuedate) {
	this.issuedate = issuedate;
}

public LocalDate getExpectedreturn() {
	return expectedreturn;
}
public void setExpectedreturn(LocalDate expectedreturn) {
	this.expectedreturn = expectedreturn;
}
public LocalDate getActualreturn() {
	return actualreturn;
}
public void setActualreturn(LocalDate actualreturn) {
	this.actualreturn = actualreturn;
}
public String getBook_name() {
	return book_name;
}
public void setBook_name(String book_name) {
	book_name = book_name;
}
public int getBook_id() {
	return book_id;
}
public void setBook_id(int book_id) {
	this.book_id = book_id;
}

}
