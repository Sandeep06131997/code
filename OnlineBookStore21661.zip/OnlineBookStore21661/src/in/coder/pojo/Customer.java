package in.coder.pojo;
public class Customer 
{
	private int customerId;
	private String customerName;
	private Long customerContact;
	private String customerAddress;
	private String customerEmail;
	private String customerPassword;
	public int getCustomerId() 
	{
		return customerId;
	}
	public void setCustomerId(int customerId)
	{
		this.customerId = customerId;
	}
	public String getCustomerName() 
	{
		return customerName;
	}
	public void setCustomerName(String customerName) 
	{
		this.customerName = customerName;
	}
	public Long getCustomerContact() 
	{
		return customerContact;
	}
	public void setCustomerContact(Long customerContact)
	{
		this.customerContact = customerContact;
	}
	public String getCustomerAddress()
	{
		return customerAddress;
	}
	public void setCustomerAddress(String customerAddress)
	{
		this.customerAddress = customerAddress;
	}
	public String getCustomerEmail()
	{
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail)
	{
		this.customerEmail = customerEmail;
	}
	public String getCustomerPassword()
	{
		return customerPassword;
	}
	public void setCustomerPassword(String customerPassword) {
		this.customerPassword = customerPassword;
	}
	@Override
	public String toString() 
	{
		return "customer [customerId=" + customerId + ", customerName=" + customerName + ", customerContact="
				+ customerContact + ", customerAddress=" + customerAddress + ", customerEmail=" + customerEmail
				+ ", customerPassword=" + customerPassword + "]";
	}


}
