package in.coder.pojo;

import java.io.InputStream;

public class Book
{
	private int bookId;
	private String bookName;
	private int bookPrice;
	private int bookQuantity;
	private String bookAuthor,bookDescription,bookPublication,bookType;
	private InputStream bookImage;
	
	public InputStream getbookImage() {
		return bookImage;
	}
	public void setbImage(InputStream bookImage) {
		this.bookImage = bookImage;
	}
	public int getBookId() {
		return bookId;
	}
	public void setBookId(int bookId) {
		this.bookId = bookId;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public int getBookPrice() {
		return bookPrice;
	}
	public void setBookPrice(int bookPrice) {
		this.bookPrice = bookPrice;
	}
	public int getBookQuantity() {
		return bookQuantity;
	}
	public void setBookQuantity(int bookQuantity) {
		this.bookQuantity = bookQuantity;
	}
	public String getBookAuthor() {
		return bookAuthor;
	}
	public void setBookAuthor(String bookAuthor) {
		this.bookAuthor = bookAuthor;
	}
	public String getBookDescription() {
		return bookDescription;
	}
	public void setBookDescription(String bookDescription) {
		this.bookDescription = bookDescription;
	}
	public String getBookPublication() {
		return bookPublication;
	}
	public void setBookPublication(String bookPublication) {
		this.bookPublication = bookPublication;
	}
	public String getBookType() {
		return bookType;
	}
	public void setBookType(String bookType) {
		this.bookType = bookType;
	}
	@Override
	public String toString() {
		return "Book [bookId=" + bookId + ", bookName=" + bookName + ", bookPrice=" + bookPrice + ", bookQuantity="
				+ bookQuantity + ", bookAuthor=" + bookAuthor + ", bookDescription=" + bookDescription
				+ ", bookPublication=" + bookPublication + ", bookType=" + bookType + "]";
	}
	

	
	
	

}
