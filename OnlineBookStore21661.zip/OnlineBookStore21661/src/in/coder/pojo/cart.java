package in.coder.pojo;

public class cart 
{
	int cartId;
	int bkId;
	String customerEmail;
	int bookQty;
	String bookName;
	int bookPrice;
	public int getCartId() {
		return cartId;
	}
	public void setCartId(int cartId) {
		this.cartId = cartId;
	}
	public int getBkId()
	{
		return bkId;
	}
	public void setBkId(int bkId)
	{
		this.bkId = bkId;
	}
	public String getCustomerEmail() {
		return customerEmail;
	}
	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}
	public int getBookQty() {
		return bookQty;
	}
	public void setBookQty(int bookQty) {
		this.bookQty = bookQty;
	}
	public String getBookName() {
		return bookName;
	}
	public void setBookName(String bookName) {
		this.bookName = bookName;
	}
	public int getBookPrice() {
		return bookPrice;
	}
	public void setBookPrice(int bookPrice) {
		this.bookPrice = bookPrice;
	}
	@Override
	public String toString() {
		return "cart [cartId=" + cartId + ", bkId=" + bkId + ", customerEmail=" + customerEmail + ", bookQty="
				+ bookQty + ", bookName=" + bookName + ", bookPrice=" + bookPrice + "]";
	}
	 
	
}
