package in.coder.dao;

public interface loginDao 
{
	boolean adminLogin(String adminEmail,String adminPassword);
	boolean customerLogin(String custEmail,String custPassword);
	boolean changePassword(String loginId,String newPassword);

}

