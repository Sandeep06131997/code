package in.coder.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import in.coder.pojo.cart;
import in.coder.utility.DBConnection;

public class cartDaoImplementation implements cartDao
{
	Connection conn=null;
	String query=null,query1=null;
	PreparedStatement ps=null;

	@Override
	public boolean bookInCart(cart ct) 
	{
		conn=DBConnection.getConnection();
		try
		{
			query="select  * from  cart21661 where bkId=? and customerEmail=?";
			ps=conn.prepareStatement(query);
			ps.setString(2,ct.getCustomerEmail());
			ps.setInt(1, ct.getBkId());
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				return true;
			}
			
			else
			{
				return false;
			}
			
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				conn.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		return false;
	}	
	@Override
	public boolean addToCart(cart c) 
	{
		conn=DBConnection.getConnection();
		
		try
		{		
			query="insert into cart21661(customerEmail,bkId,bookQty) values(?,?,?)";
			ps=conn.prepareStatement(query);
			ps.setString(1,c.getCustomerEmail());
			ps.setInt(2, c.getBkId());
			ps.setInt(3, c.getBookQty());
			int row=ps.executeUpdate();
			if(row>0)
			{
				return true;
			}
			else
			{
				return false;
			}
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				conn.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		return false;
	}

	@Override
	public boolean deleteCart(int cartId) 
	{
		conn=DBConnection.getConnection();
		query="delete from cart21661 where cartId=?";
		try
		{
			ps=conn.prepareStatement(query);
			ps.setInt(1, cartId);
			int row=ps.executeUpdate();
			if(row>0)
			{
				return true;
			}
			else
			{
				System.out.println("ERROR");
			}
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				conn.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		return false;
	}

	public List<cart> showCart(String cemail)
	{
		List<cart> l=new ArrayList<cart>();

		conn=DBConnection.getConnection();
		query="select cartId,bkId,bookQty,bookName,bookPrice from book21661 p inner join "
				+ "cart21661 c on p.bookId=c.bkId and customerEmail=?";
		{
			try 
			{
				ps=conn.prepareStatement(query);
				ps.setString(1, cemail);

				ResultSet rs=ps.executeQuery();
				while(rs.next())
				{
					cart c=new cart();
					c.setCartId(rs.getInt(1));
					c.setBkId(rs.getInt(2));
					c.setBookQty(rs.getInt(3));
					c.setBookName(rs.getString(4));
					c.setBookPrice(rs.getInt(5));
					l.add(c);
				}
			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			}
			finally
			{
				try 
				{
					conn.close();
				}
				catch (SQLException e) 
				{
					e.printStackTrace();
				}
			}
		}
		return l;
	}

	@Override
	public boolean placeOrder(String email) 
	{
		double totalBill=0;
		conn=DBConnection.getConnection();
		query="select sum(b.bookPrice * c.bookQty) as total from "
				+ "book21661 b inner join  cart21661 c on b.bookId=c.bkId and customerEmail=?";
		try {
			ps=conn.prepareStatement(query);
			ps.setString(1, email);;

			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				totalBill=rs.getDouble("total");
				
			}
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		query1="insert into order21661(totalBill,customerEmail) values (?,?)";
		try 
		{
			ps=conn.prepareStatement(query1);
			ps.setDouble(1, totalBill);
			ps.setString(2, email);
			int row=ps.executeUpdate();
			if(row>0)
			{
				return true;
			}
			else
			{
				return false;
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		return false;

	}

	
}

