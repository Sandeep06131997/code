package in.coder.dao;
import java.util.List;

import in.coder.pojo.*;
public interface customerDao 
{
	boolean addCustomer(Customer c);
	boolean updateCustomer(Customer c);
	boolean deleteCustomer(int CustomerId);
	Customer displaysingleCustomer(int CustomerId);
	List<Customer> displayAllCustomers();
	Customer  customerDisplayByEmail(String customerEmail);
}
