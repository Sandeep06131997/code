package in.coder.dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import in.coder.utility.*;
public class loginDaoImplementation implements loginDao
{

	@Override
	public boolean adminLogin(String adminEmail, String adminPassword) {
		Connection conn = DBConnection.getConnection();
		String query="select * from admin21661 where adminEmail=? and adminPassword=?";
		try {
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setString(1, adminEmail);
			ps.setString(2, adminPassword);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				return true;
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		
		finally {
			try {
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}		return false;
	}

	@Override
	public boolean customerLogin(String custEmail, String custPassword) {
		Connection conn = DBConnection.getConnection();
		String query="select * from customer21661 where customerEmail=? and customerPassword=?";
		try 
		{
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setString(1, custEmail);
			ps.setString(2, custPassword);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				return true;
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		finally {
			try {
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return false;
	}

	@Override
	public boolean changePassword(String loginId, String newPassword)
	{
		Connection conn = DBConnection.getConnection();
		String query="update  admin21661 set adminPassword=? where adminEmail=?";
		try 
		{
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setString(1, newPassword);
			ps.setString(2, loginId);
			int row=ps.executeUpdate();
			if(row>0)
			{
				return true;
			}
			else
			{
				return false;
			}
			
		} 
		catch (Exception e) 
		{
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return false;
	}

}
