package in.coder.dao;
import java.util.List;

import in.coder.pojo.*;
public interface bookDao 
{
	boolean addBook(Book b);
	boolean updateBook(Book b);
	boolean deleteBook(int bookId);
	Book displaySingleBook(int bookId);
	List<Book>displayAllBooks();
	
	List<Book> displayAllPublication();
	List<Book> displayAllBookType();
	List<Book> displayBookByBookType(String bookType);
	List<Book> displayBookByBookPublication(String bookPublication);
	List<Book> searchBook(String bname);
}
