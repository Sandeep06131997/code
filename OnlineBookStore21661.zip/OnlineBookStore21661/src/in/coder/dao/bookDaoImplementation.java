package in.coder.dao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import in.coder.pojo.Book;
import in.coder.utility.DBConnection;

public class bookDaoImplementation implements bookDao
{
	Connection conn=null;
	String query=null;
	PreparedStatement ps=null;
	@Override
	public boolean addBook(Book b) 
	{

		conn=DBConnection.getConnection();
		query="insert into book21661(bookName,bookPrice,bookQuantity,bookAuthor,"
				+ "bookPublication,bookDescription,bookType,bookImage) values(?,?,?,?,?,?,?,?)";
		try {
			ps=conn.prepareStatement(query);
			ps.setString(1, b.getBookName());
			ps.setInt(2, b.getBookPrice());
			ps.setInt(3, b.getBookQuantity());
			ps.setString(4, b.getBookAuthor());
			ps.setString(5, b.getBookPublication());
			ps.setString(6, b.getBookDescription());
			ps.setString(7, b.getBookType());
			ps.setBinaryStream(8, b.getbookImage());
			int row=ps.executeUpdate();
			if(row>0)
			{
				return true;
			}
			else
			{
				System.out.println("ERROR");
			}

		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				conn.close();
			} catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
		return false;
	}

	@Override
	public boolean updateBook(Book b) 
	{
		conn=DBConnection.getConnection();
		try {
			if(b.getbookImage()!=null)
			{
				ps=conn.prepareStatement("update book21661 set bookImage=? where bookId=?");
				ps.setInt(2,b.getBookId());
				ps.setBinaryStream(1, b.getbookImage());
				int i=ps.executeUpdate();
				
			}

			query="update book21661 set bookName=?,bookPrice=?,bookQuantity=?,"
					+ "bookAuthor=?,bookDescription=?,bookPublication=?,bookType=? where bookId=?";

			ps=conn.prepareStatement(query);
			ps.setString(1, b.getBookName());
			ps.setDouble(2, b.getBookPrice());
			ps.setInt(3, b.getBookQuantity());
			ps.setString(4, b.getBookAuthor());
			ps.setString(6, b.getBookPublication());
			ps.setString(5, b.getBookDescription());
			ps.setString(7, b.getBookType());
			ps.setInt(8, b.getBookId());
			int row=ps.executeUpdate();
			if(row>0)
			{
				return true;
			}
			else
			{
				return false;			
				}

		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				conn.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		return false;
	}
	@Override
	public boolean deleteBook(int bookId)
	{
		conn=DBConnection.getConnection();
		query="delete from book21661 where bookId=?";
		try {
			ps=conn.prepareStatement(query);
			ps.setInt(1, bookId);
			int row=ps.executeUpdate();
			if(row>0)
			{
				return true;
			}
			else
			{
				System.out.println("ERROR");
			}
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				conn.close();
			} 
			catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
		return false;
	}
	@Override
	public Book displaySingleBook(int bookId)
	{
		conn=DBConnection.getConnection();
		query="select * from book21661 where bookId=?";
		try {
			ps=conn.prepareStatement(query);
			ps.setInt(1, bookId);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Book b=new Book();
				b.setBookId(rs.getInt(1));
				b.setBookName(rs.getString(2));
				b.setBookPrice(rs.getInt(3));
				b.setBookQuantity(rs.getInt(4));
				b.setBookAuthor(rs.getString(5));
				b.setBookDescription(rs.getString(6));
				b.setBookPublication(rs.getString(7));
				b.setBookType(rs.getString(8));
				b.setbImage(rs.getBinaryStream(9));
				return b;
			}
			System.out.println();
		}
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				conn.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		return null;	
	}

	@Override
	public List<Book> displayAllBooks() 
	{
		List<Book> b1=new ArrayList<Book>();
		{
			conn=DBConnection.getConnection();
			query="select * from book21661";
			try 
			{
				ps=conn.prepareStatement(query);
				ResultSet rs=ps.executeQuery();
				while(rs.next())
				{
					Book b=new Book();
					b.setBookId(rs.getInt(1));
					b.setBookName(rs.getString(2));
					b.setBookPrice(rs.getInt(3));
					b.setBookQuantity(rs.getInt(4));
					b.setBookAuthor(rs.getString(5));
					b.setBookDescription(rs.getString(6));
					b.setBookPublication(rs.getString(7));
					b.setBookType(rs.getString(8));
					b1.add(b);
				}
				return b1;
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			finally 
			{
				try
				{
					conn.close();
				}
				catch (SQLException e)
				{
					e.printStackTrace();
				}
			}
			return null;
		}
	}

	@Override
	public List<Book> displayAllPublication()
	{
		List<Book> bl=new ArrayList<>();
		conn=DBConnection.getConnection();
		String query="select bookPublication from book21661";
		try 
		{
			PreparedStatement ps=conn.prepareStatement(query);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Book b=new Book();
				b.setBookPublication(rs.getString(1));
				bl.add(b);
			}
			return bl;


		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	@Override
	public List<Book> displayAllBookType()
	{
		List<Book> bl=new ArrayList<>();
		conn=DBConnection.getConnection();
		String query="select bookType from book21661";
		try 
		{
			PreparedStatement ps=conn.prepareStatement(query);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Book b=new Book();
				b.setBookType(rs.getString(1));
				bl.add(b);
			}
			return bl;

		} catch (Exception e) {
			e.printStackTrace();
		}
		finally {
			try {
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	@Override
	public List<Book> displayBookByBookType(String bookType) 
	{
		List<Book> bl=new ArrayList<>();

		conn=DBConnection.getConnection();
		String query="select * from book21661 where bookType=?";
		try 
		{
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setString(1, bookType);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Book b=new Book();
				b.setBookId(rs.getInt(1));
				b.setBookName(rs.getString(2));
				b.setBookPrice(rs.getInt(3));
				b.setBookQuantity(rs.getInt(4));
				b.setBookAuthor(rs.getString(5));
				b.setBookPublication(rs.getString(6));
				b.setBookDescription(rs.getString(7));
				bl.add(b);

			}
			return bl;


		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public List<Book> displayBookByBookPublication(String bookPublication) 
	{
		List<Book> bl=new ArrayList<>();

		conn=DBConnection.getConnection();
		String query="select * from book21661 where bookPublication=?";
		try 
		{
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setString(1, bookPublication);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Book b=new Book();
				b.setBookId(rs.getInt(1));
				b.setBookName(rs.getString(2));
				b.setBookPrice(rs.getInt(3));
				b.setBookQuantity(rs.getInt(4));
				b.setBookAuthor(rs.getString(5));
				b.setBookDescription(rs.getString(7));
				b.setBookType(rs.getString(8));
				bl.add(b);
			}
			return bl;
		}
		catch (Exception e)
		{
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public List<Book> searchBook(String bname) 
	{
		List<Book> bl=new ArrayList<>();
		conn=DBConnection.getConnection();
		String query="select * from book21661 where bookName like ?";
		try
		{
			PreparedStatement ps=conn.prepareStatement(query);
			ps.setString(1, '%'+bname+'%');
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Book b=new Book();
				b.setBookId(rs.getInt(1));
				b.setBookName(rs.getString(2));
				b.setBookPrice(rs.getInt(3));
				b.setBookQuantity(rs.getInt(4));
				b.setBookAuthor(rs.getString(5));
				b.setBookPublication(rs.getString(6));
				b.setBookDescription(rs.getString(7));
				bl.add(b);

			}
			return bl;
		} 
		catch (SQLException e)
		{
			e.printStackTrace();
		}
		return null;
	}
}
