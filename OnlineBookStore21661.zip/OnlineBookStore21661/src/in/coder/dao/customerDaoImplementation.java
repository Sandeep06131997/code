package in.coder.dao;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import in.coder.pojo.Book;
import in.coder.pojo.Customer;
import in.coder.utility.DBConnection;

public class customerDaoImplementation implements customerDao
{
	Connection conn=null;
	String query=null;
	PreparedStatement ps=null;
	@Override
	public boolean addCustomer(Customer c) 
	{
		conn=DBConnection.getConnection();
		query="insert into customer21661(customerName,customerContact"
				+ ",customerAddress,customerEmail,customerPassword) values (?,?,?,?,?)";
		try 
		{
			ps=conn.prepareStatement(query);
			ps.setString(1, c.getCustomerName());
			ps.setLong(2, c.getCustomerContact());
			ps.setString(3, c.getCustomerAddress());
			ps.setString(4, c.getCustomerEmail());
			ps.setString(5, c.getCustomerPassword());
			int row=ps.executeUpdate();
			if(row>0)
			{
				return true;
			}
			else
			{
				System.out.println("ERROR");
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				conn.close();
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		return false;
	}

	@Override
	public boolean updateCustomer(Customer c) 
	{
		conn=DBConnection.getConnection();
		query="update customer21661 set customerName=?,customerContact=?,customerAddress=?"
				+ ",customerEmail=?,customerPassword=? where customerId=?";
		try 
		{
			ps=conn.prepareStatement(query);
			ps.setString(1, c.getCustomerName());
			ps.setLong(2, c.getCustomerContact());
			ps.setString(3, c.getCustomerAddress());
			ps.setString(4, c.getCustomerEmail());
			ps.setString(5, c.getCustomerPassword());
			ps.setInt(6, c.getCustomerId());
			int row=ps.executeUpdate();
			if(row>0)
			{
				return true;
			}
			else
			{
				System.out.println("ERROR");
			}

		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try {
				conn.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		return false;	
	}

	@Override
	public boolean deleteCustomer(int CustomerId) 
	{
		conn=DBConnection.getConnection();
		query="delete from customer21661 where customerId=?";
		try {
			ps=conn.prepareStatement(query);
			ps.setInt(1, CustomerId);
			int row=ps.executeUpdate();
			if(row>0)
			{
				return true;
			}
			else
			{
				System.out.println("ERROR");
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				conn.close();
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
		}
		return false;
	}

	@Override
	public Customer displaysingleCustomer(int CustomerId) 
	{
		conn=DBConnection.getConnection();
		query="select * from customer21661 where customerId=?";
		try
		{
			ps=conn.prepareStatement(query);
			ps.setInt(1, CustomerId);
			ResultSet rs=ps.executeQuery();
			while(rs.next())
			{
				Customer c=new Customer();
				c.setCustomerId(rs.getInt(1));
				c.setCustomerName(rs.getString(2));
				c.setCustomerContact(rs.getLong(3));
				c.setCustomerAddress(rs.getString(4));
				c.setCustomerEmail(rs.getString(5));
				c.setCustomerPassword(rs.getString(6));

				return c;
			}
		} 
		catch (SQLException e) 
		{
			e.printStackTrace();
		}
		finally
		{
			try 
			{
				conn.close();
			} catch (SQLException e)
			{
				e.printStackTrace();
			}
		}
		return null;
	}

	
	public List<Customer> displayAllCustomers() 
	{
		List<Customer> c1=new ArrayList<Customer>();
		{
			conn=DBConnection.getConnection();
			query="select * from customer21661";
			try 
			{
				ps=conn.prepareStatement(query);
				ResultSet rs=ps.executeQuery();
				while(rs.next())
				{
					Customer c=new Customer();
					c.setCustomerId(rs.getInt(1));
					c.setCustomerName(rs.getString(2));
					c.setCustomerContact(rs.getLong(3));
					c.setCustomerAddress(rs.getString(4));
					c.setCustomerEmail(rs.getString(5));
					c.setCustomerPassword(rs.getString(6));
					c1.add(c);
				}
				return c1;
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			finally 
			{
				try
				{
					conn.close();
				}
				catch (SQLException e)
				{
					e.printStackTrace();
				}
			}
			return null;
		}
	}

	
	

	@Override
	public Customer customerDisplayByEmail(String customerEmail)
	{
		conn=DBConnection.getConnection();	
			query="select * from customer21661 where customerEmail=?";
			try 
			{
				ps=conn.prepareStatement(query);
				ps.setString(1, customerEmail);
				ResultSet rs=ps.executeQuery();

				while(rs.next())
				{
					Customer c=new Customer();
					c.setCustomerId(rs.getInt(1));
					c.setCustomerName(rs.getString(2));
					c.setCustomerContact(rs.getLong(3));
					c.setCustomerAddress(rs.getString(4));
					c.setCustomerEmail(rs.getString(5));
					c.setCustomerPassword(rs.getString(6));
					return c;
				}
				
			}
			catch (SQLException e) 
			{
				e.printStackTrace();
			}
			finally 
			{
				try
				{
					conn.close();
				}
				catch (SQLException e)
				{
					e.printStackTrace();
				}
			}
		return null;
	}
}