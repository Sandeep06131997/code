package in.coder.dao;
import java.util.List;
import in.coder.pojo.cart;
public interface cartDao
{
	boolean addToCart(cart c);
	boolean deleteCart(int cartId);
	List<cart> showCart(String email);
	boolean placeOrder(String email);
	boolean bookInCart(cart ct);
}
