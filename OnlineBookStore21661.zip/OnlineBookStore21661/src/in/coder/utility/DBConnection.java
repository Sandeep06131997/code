package in.coder.utility;
import java.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection
{
	public static Connection getConnection()
	{
		Connection conn=null;
		try 
		{
			Class.forName("com.mysql.jdbc.Driver");
			String url="jdbc:mysql://localhost:3306/BOOKSTORE21661";
			conn=DriverManager.getConnection(url,"root","");
			return conn;
		} 
		catch (Exception e)
		{
			e.printStackTrace();
		}
		return null;
	}

}
