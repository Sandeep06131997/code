package in.coder.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import in.coder.dao.customerDaoImplementation;
import in.coder.pojo.Book;
import in.coder.pojo.Customer;


@WebServlet("/CommonCustomerServlet")
public class CommonCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    String cName,cAddress,cEmail,cPassword;
    long cContact;
    int cId,cid;
    boolean flag=false;
    
    Customer c=new Customer();
    customerDaoImplementation cs=new customerDaoImplementation();
    
    public CommonCustomerServlet() 
    {
    	
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		String operation=request.getParameter("action");
		if(operation!=null && operation.equalsIgnoreCase("delete"))
		{
		    cid=Integer.parseInt(request.getParameter("cid"));
			flag=cs.deleteCustomer(cid);
			if(flag)
			{
				response.sendRedirect("CommonCustomerServlet");
			}
			else
			{
				response.sendRedirect("error.html");
			}
		}
		else if(operation!=null && operation.equalsIgnoreCase("update"))
		{
			cid=Integer.parseInt(request.getParameter("cid"));
			Customer c=cs.displaysingleCustomer(cid);
			session.setAttribute("customer", c);
			response.sendRedirect("CustomerValidation.jsp");
	
		}
		else if(operation!=null && operation.equalsIgnoreCase("editprofile"))
		{
			String email=(String)session.getAttribute("custLogin");
			Customer c=cs.customerDisplayByEmail(email);
			session.setAttribute("customer", c);
			response.sendRedirect("CustomerValidation.jsp");
			
		}
		else
		{
		List<Customer>cl=cs.displayAllCustomers();	
		session.setAttribute("customerList", cl);
		response.sendRedirect("home.jsp");
		}
		//response.getWriter().append("Server at: ").append(request.getContentType());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String operation=request.getParameter("action");
		System.out.println(operation);
		if(operation!=null && operation.equalsIgnoreCase("addcustomer"))
		{
		cName=request.getParameter("cName");
		cContact=Long.parseLong(request.getParameter("cContact"));
		cAddress=request.getParameter("cAddress");
		cEmail=request.getParameter("cEmail");
		cPassword=request.getParameter("cPassword");
		
		c.setCustomerName(cName);
		c.setCustomerContact(cContact);
		c.setCustomerAddress(cAddress);
		c.setCustomerEmail(cEmail);
		c.setCustomerPassword(cPassword);
		
		flag=cs.addCustomer(c);
		if(flag)
		{
			response.sendRedirect("success.html");

		}
		else
		{
			response.sendRedirect("Error.html");

		}
		}
		
		else if(operation!=null && operation.equalsIgnoreCase("updatecustomer"))
		{
			int cId=Integer.parseInt(request.getParameter("cId"));
			cName=request.getParameter("cName");
			cContact=Long.parseLong(request.getParameter("cContact"));
			cAddress=request.getParameter("cAddress");
			cEmail=request.getParameter("cEmail");
			cPassword=request.getParameter("cPassword");
			
			c.setCustomerId(cId);
			c.setCustomerName(cName);
			c.setCustomerContact(cContact);
			c.setCustomerAddress(cAddress);
			c.setCustomerEmail(cEmail);
			c.setCustomerPassword(cPassword);
			flag=cs.updateCustomer(c);
			System.out.println(flag);
			if(flag)
			{
				response.sendRedirect("CommonCustomerServlet");
			}
			else
			{
				response.sendRedirect("CustomerValidation.jsp");
			}
			
				
		/*doGet(request, response);*/
	}
	}

}