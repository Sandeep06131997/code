package in.coder.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.coder.dao.bookDaoImplementation;
import in.coder.pojo.Book;


@WebServlet("/updateBookServlet")
public class updateBookServlet extends HttpServlet 
{
	private static final long serialVersionUID = 1L;
	String bookName,bookAuthor,bookPublication,bookDescription,bookType;   
    int bookPrice;
    int bookId,bookQuantity;
    boolean flag=false;
    Book b=new Book();
	bookDaoImplementation bdi=new bookDaoImplementation();
	
    
    public updateBookServlet() {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		bookId=Integer.parseInt(request.getParameter("bookId"));		//textbox name
		bookName=request.getParameter("bookName");	
		bookPrice=Integer.parseInt(request.getParameter("bookPrice"));
		bookQuantity=Integer.parseInt(request.getParameter("bookQuantity"));
		bookAuthor=request.getParameter("bookAuthor");
		bookPublication=request.getParameter("bookPublication");
		bookDescription=request.getParameter("bookDescription");
		bookType=request.getParameter("bookType");
		
		b.setBookId(bookId);
		b.setBookName(bookName);
		b.setBookPrice(bookPrice);
		b.setBookQuantity(bookQuantity);
		b.setBookAuthor(bookAuthor);
		b.setBookPublication(bookPublication);
		b.setBookDescription(bookDescription);
		b.setBookType(bookType);
		
		flag=bdi.updateBook(b);
		if(flag)
		{
			response.sendRedirect("success.html");
		}
		else
		{
			response.sendRedirect("failure.html");
		}
		
		doGet(request, response);
	}

}