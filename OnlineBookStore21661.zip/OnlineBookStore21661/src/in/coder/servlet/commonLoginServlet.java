package in.coder.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import in.coder.dao.customerDaoImplementation;
import in.coder.dao.loginDaoImplementation;


@WebServlet("/commonLoginServlet")
public class commonLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	loginDaoImplementation ldi=new loginDaoImplementation();
	customerDaoImplementation cdi=new customerDaoImplementation();
	boolean flag=false;


	public commonLoginServlet()
	{
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		session.invalidate();
		response.sendRedirect("index.jsp");
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		String operation=request.getParameter("action");
		if(operation!=null && operation.equalsIgnoreCase("login"))
		{
			String type=request.getParameter("type");
			String email=request.getParameter("email");
			String password=request.getParameter("password");
			if(type.equalsIgnoreCase("admin"))
			{
				flag=ldi.adminLogin(email, password);
				if(flag)

				{
					session.setAttribute("adminLogin",email);
					// response.sendRedirect("index.jsp");
					request.setAttribute("success", "Welcome to BookStore");
					RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
					rd.forward(request, response);
				}


				else
				{				 
					// response.sendRedirect("login.jsp");
					request.setAttribute("failed", "Please check the UserName and Password");
					RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
					rd.forward(request, response);
				}


			}
			else if(type.equalsIgnoreCase("customer"))
			{
				flag=ldi.customerLogin(email,password);
				if(flag)
				{
					session.setAttribute("custLogin",email);
					//response.sendRedirect("index.jsp");
					request.setAttribute("success", "Welcome to BookStore");
					RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
					rd.forward(request, response);
				}
				else
				{				
					//response.sendRedirect("login.jsp");
					request.setAttribute("failed", "Please check the UserName and Password");
					RequestDispatcher rd=request.getRequestDispatcher("login.jsp");
					rd.forward(request, response);
				}
			}
		}
		else if(operation!=null && operation.equalsIgnoreCase("changepassword"))
		{
			String email=request.getParameter("email");
			String oldpassword=request.getParameter("oldpassword");
			String newpassword=request.getParameter("newpassword");
			if(ldi.adminLogin(email, oldpassword))
			{
				flag=ldi.changePassword(email, newpassword);
				if(flag)
				{
					//response.sendRedirect("success.html");
					request.setAttribute("success", "Password successfully changed");
					RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
					rd.forward(request, response);
				}
				else
				{
					//response.sendRedirect("error.html");
					request.setAttribute("failed", "Invalid Password");
					RequestDispatcher rd=request.getRequestDispatcher("changePassword.jsp");
					rd.forward(request, response);
				}
			}
		}				
	}

}