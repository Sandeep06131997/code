package in.coder.servlet;

import java.util.List;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import in.coder.dao.bookDaoImplementation;
import in.coder.pojo.Book;

@WebServlet("/CommonBookServlet")
@MultipartConfig(maxFileSize=123545645)
public class CommonBookServlet extends HttpServlet
{
	private static final long serialVersionUID = 1L;
	String bookName,bookAuthor,bookDescription,bookPublication,bookType;
	int bookPrice;
	int bookQuantity,bookId;
	boolean flag=false;

	Book b=new Book();
	bookDaoImplementation bd=new bookDaoImplementation();


	public CommonBookServlet() 
	{
		super();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		HttpSession session=request.getSession();
		String operation=request.getParameter("action");
		if(operation!=null && operation.equalsIgnoreCase("delete"))
		{
			int bid=Integer.parseInt(request.getParameter("bid"));
			flag=bd.deleteBook(bid);
			if(flag)
			{
				response.sendRedirect("CommonBookServlet");
			}
			else
			{
				response.sendRedirect("error.html");
			}
		}
		else if(operation!=null && operation.equalsIgnoreCase("update"))
		{
			int bid=Integer.parseInt(request.getParameter("bid"));
			Book b=bd.displaySingleBook(bid);
			session.setAttribute("bookList", b);
			response.sendRedirect("Bookvalidation.jsp");

		}
		else if(operation!=null && operation.equalsIgnoreCase("category"))
		{
			String cat=request.getParameter("cat");
			List<Book> bcat=bd.displayBookByBookType(cat);
			session.setAttribute("bookList", bcat);
			response.sendRedirect("home.jsp");

		}
		else if(operation!=null && operation.equalsIgnoreCase("search"))
		{
			String b=request.getParameter("bname");
			List<Book> bs=bd.searchBook(b);
			session.setAttribute("bookList", bs);
			response.sendRedirect("home.jsp");

		}
		else if(operation!=null && operation.equalsIgnoreCase("publisher"))
		{
			String pub=request.getParameter("pub");
			List<Book> bpub=bd.displayBookByBookPublication(pub);
			session.setAttribute("bookList", bpub);
			response.sendRedirect("home.jsp");
		}
		else if(operation!=null && operation.equalsIgnoreCase("blist"))
		{
			String list=request.getParameter("blist");
			List<Book>blist=bd.displayAllBooks();	
			session.setAttribute("bookList", blist);
			response.sendRedirect("bookList.jsp");
		}
		else
		{
			List<Book>blist=bd.displayAllBooks();	
			session.setAttribute("bookList", blist);
			List<Book> clist=bd.displayAllBookType();
			session.setAttribute("catlist", clist);
			List<Book> pl=bd.displayAllPublication();
			session.setAttribute("publist", pl);
			response.sendRedirect("home.jsp");

		}
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String operation=request.getParameter("action");
		if(operation!=null && operation.equalsIgnoreCase("addbook"))
		{

			bookName=request.getParameter("bookName");
			bookPrice=Integer.parseInt(request.getParameter("bookPrice"));
			bookQuantity=Integer.parseInt(request.getParameter("bookQuantity"));
			bookAuthor=request.getParameter("bookAuthor");
			bookDescription=request.getParameter("bookDescription");
			bookPublication=request.getParameter("bookPublication");
			bookType=request.getParameter("bookType");

			Part p=request.getPart("bImage");
			InputStream img=p.getInputStream();//convert img into byte
			b.setbImage(img);
			
			b.setBookName(bookName);
			b.setBookPrice(bookPrice);
			b.setBookQuantity(bookQuantity);
			b.setBookAuthor(bookAuthor);
			b.setBookDescription(bookDescription);
			b.setBookPublication(bookPublication);
			b.setBookType(bookType);

			flag=bd.addBook(b);
			if(flag)
			{
				response.sendRedirect("success.html");
			}
			else
			{
				response.sendRedirect("error.html");

			}
		}
		else if(operation!=null && operation.equalsIgnoreCase("updatebook"))
		{
			Book b=new Book();
			bookId=Integer.parseInt(request.getParameter("bookId"));
			bookName=request.getParameter("bookName");	//textbox name
			bookPrice=Integer.parseInt(request.getParameter("bookPrice"));
			bookQuantity=Integer.parseInt(request.getParameter("bookQuantity"));
			bookAuthor=request.getParameter("bookAuthor");
			bookPublication=request.getParameter("bookPublication");
			bookDescription=request.getParameter("bookDescription");
			bookType=request.getParameter("bookType");
			Part p=request.getPart("bImage");
			if(p.getSize()!=0)
			{
			InputStream img=p.getInputStream();//convert img into byte
			b.setbImage(img);
			}
			b.setBookId(bookId);
			b.setBookName(bookName);
			b.setBookPrice(bookPrice);
			b.setBookQuantity(bookQuantity);
			b.setBookAuthor(bookAuthor);
			b.setBookPublication(bookPublication);
			b.setBookDescription(bookDescription);
			b.setBookType(bookType);

			flag=bd.updateBook(b);
			if(flag)
			{
				response.sendRedirect("CommonBookServlet");
			}
			else
			{
				response.sendRedirect("BookValidation.jsp");
			}
		}	
		/*doGet(request, response);*/
	}

}


