package in.coder.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import in.coder.dao.customerDaoImplementation;
import in.coder.pojo.Customer;


@WebServlet("/updateCustomerServlet")
public class updateCustomerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	int cId;
	String cName,cAddress,cEmail,cPassword;
    long cContact;
    boolean flag=false;
    Customer c=new Customer();
    customerDaoImplementation cdi=new customerDaoImplementation();
    public updateCustomerServlet()
    {
        super();
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		cId=Integer.parseInt(request.getParameter("cId"));
		cName=request.getParameter("cName");
		cContact=Long.parseLong(request.getParameter("cContact"));
		cAddress=request.getParameter("cAddress");
		cEmail=request.getParameter("cEmail");
		cPassword=request.getParameter("cPassword");
		
		c.setCustomerId(cId);
		c.setCustomerName(cName);
		c.setCustomerContact(cContact);
		c.setCustomerAddress(cAddress);
		c.setCustomerEmail(cEmail);
		c.setCustomerPassword(cPassword);
		
		flag=cdi.updateCustomer(c);
		if(flag)
		{
			response.sendRedirect("success.html");
		}
		else
		{
			response.sendRedirect("failure.html");
		}
		doGet(request, response);
	}

}