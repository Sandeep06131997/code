package in.coder.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import in.coder.dao.cartDaoImplementation;
import in.coder.pojo.Book;
import in.coder.pojo.Customer;
import in.coder.pojo.cart;

@WebServlet("/CommonOrderServlet")
public class CommonOrderServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	cart c= new cart();
    boolean flag=false;
    cartDaoImplementation cdi=new cartDaoImplementation();
    public CommonOrderServlet() 
    {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		HttpSession session=request.getSession();
		String operation=request.getParameter("action");
		
		if(operation!=null && operation.equalsIgnoreCase("addincart"))
		{	
			String email=(String)session.getAttribute("custLogin");
			int bookId=Integer.parseInt(request.getParameter("bid"));
			c.setBkId(bookId);
			c.setCustomerEmail(email);
			c.setBookQty(1);
			flag=cdi.addToCart(c);
			if(flag)
			{
				//response.sendRedirect("success.html");

				request.setAttribute("failed", "Book is already in cart");
				RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
				rd.forward(request, response);
			}
			else
			{
				flag=cdi.addToCart(c);
				if(flag)
				{
				//response.sendRedirect("error.html");
				request.setAttribute("success", "Book is Added in cart");
				RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
				rd.forward(request, response);
				}
				else
				{
					request.setAttribute("failed", "Error in adding book");
					RequestDispatcher rd=request.getRequestDispatcher("home.jsp");
					rd.forward(request, response);
				}
			}			
		}
		
		else if(operation!=null && operation.equalsIgnoreCase("displaycart"))
			{
				String email=(String)session.getAttribute("custLogin");
				List<cart>clist=cdi.showCart(email);
				session.setAttribute("cartList", clist);
				response.sendRedirect("cartList.jsp");
			}
		
		else if(operation!=null && operation.equalsIgnoreCase("delete"))
		{
			int cid=Integer.parseInt(request.getParameter("cid"));
			flag=cdi.deleteCart(cid);
			if(flag)
			{
				response.sendRedirect("CommonOrderServlet");
			}
			else
			{
				response.sendRedirect("error.html");
			}
		}
		else
		{
			String email=(String)session.getAttribute("custLogin");
			List<cart>clist=cdi.showCart(email);
			session.setAttribute("cartList", clist);
			response.sendRedirect("cartList.jsp");
		}
		
		//response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				doGet(request, response);
	}

}
