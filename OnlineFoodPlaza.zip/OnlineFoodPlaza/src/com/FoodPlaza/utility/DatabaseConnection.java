package com.FoodPlaza.utility;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnection {
public static Connection establishConnection() {
	Connection c=null;
	

try
{
	Class.forName("com.mysql.jdbc.Driver");
	c=DriverManager.getConnection("jdbc:mysql://localhost:3306/foodplaza_sandeep79","root","");
	return c;
}
catch(Exception e)

{
e.printStackTrace();	
}
	return null;
}

}
