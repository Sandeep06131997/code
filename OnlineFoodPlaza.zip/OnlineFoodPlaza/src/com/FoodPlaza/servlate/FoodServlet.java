package com.FoodPlaza.servlate;

import java.util.List;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.FoodPlaza.dao.FoodDaoImpl;
import com.FoodPlaza.pojo.Food;

/**
 * Servlet implementation class FoodServlet
 */
@WebServlet("/FoodServlet")
@MultipartConfig(maxFileSize=50897654)
public class FoodServlet extends HttpServlet {
	
	Food f=new Food();
	FoodDaoImpl fi=new FoodDaoImpl();
	boolean flag=false;
	RequestDispatcher rd;

	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public FoodServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s = request.getSession();
		String operation=request.getParameter("action");
		if(operation!=null && operation.equals("Update"))
		{
			int fid=Integer.parseInt(request.getParameter("FoodId"));
			f=fi.searchFood(fid);
			s.setAttribute("FoodDetails", f);
			response.sendRedirect("UpdateFood.jsp");
			
		}
		else if(operation!=null && operation.equals("Delete")) 
		{

			int fid=Integer.parseInt(request.getParameter("FoodId"));
			flag=fi.deleteFood(fid);
			if(flag== true)
			{
				request.setAttribute("Delete","Delete sucessfully");
				rd=request.getRequestDispatcher("Index.jsp");
				rd.forward(request, response);

				//response.sendRedirect("FoodServlet");
			}
			else
			{
				request.setAttribute("Error", "opps? something went wrong please try again");
				rd=request.getRequestDispatcher("Index.jsp");
				rd.forward(request, response);
				//response.sendRedirect("error.html");
			}
			
		}
		else if(operation!=null && operation.equalsIgnoreCase("search"))
		{
			String name=request.getParameter("FoodName");
			List<Food>flist=fi.searchFoodByName(name);
			if(!flist.isEmpty())
			{
				s.setAttribute("foodList",flist );
				response.sendRedirect("FoodList.jsp");
			}
			else
			{
				request.setAttribute("Error", "opps? something went wrong please try again");
				rd=request.getRequestDispatcher("Index.jsp");
				rd.forward(request, response);
				//response.sendRedirect("error..html");
			}
			
			
		}
	else
	{
		
		List<Food> flist=fi.displayFood();
		s.setAttribute("foodList",flist );
		response.sendRedirect("FoodList.jsp");
	}



	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		

		
		
		String operation=request.getParameter("action");
		
		if(operation!=null && operation.equals("AddFood"))
			
		{
			
			String name=request.getParameter("foodname");
			double price=Double.parseDouble(request.getParameter("foodPrice"));
			String category=request.getParameter("foodcategory");
			Part p=request.getPart("FoodImage");
			f.setFoodName(name);
			f.setFoodPrice(price);
			f.setFoodCategory(category);
			
			InputStream is=p.getInputStream();
			if(is!=null)
			{
				f.setFoodImage(is);
			}
			
			flag=fi.addFood(f);

			if(flag== true)
			{
				request.setAttribute("Food","Food Added sucessfully");
				rd=request.getRequestDispatcher("Index.jsp");
				rd.forward(request, response);
				//response.sendRedirect("Sucess.html");
			}
			else
			{
				request.setAttribute("Error", "opps? something went wrong please try again");
				rd=request.getRequestDispatcher("Index.jsp");
				rd.forward(request, response);
				//response.sendRedirect("error.html");
			}
				
		}
		else if(operation!=null && operation.equals("UpdateFood"))
		{
			int fid=Integer.parseInt(request.getParameter("foodid"));
			String name=request.getParameter("foodname");
			double price=Double.parseDouble(request.getParameter("foodPrice"));
			String category=request.getParameter("foodcategory");
			f.setFoodId(fid);
			f.setFoodName(name);
			f.setFoodPrice(price);
			f.setFoodCategory(category);
			flag=fi.updateFood(f);

			if(flag== true)
			{
				request.setAttribute("Update","Food Updateed sucessfully");
				rd=request.getRequestDispatcher("Index.jsp");
				rd.forward(request, response);
				//response.sendRedirect("FoodServlet");
			}
			else
			{
				request.setAttribute("Error", "opps? something went wrong please try again");
				rd=request.getRequestDispatcher("Index.jsp");
				rd.forward(request, response);
				//response.sendRedirect("error.html");
			}
			
			
		}
		
	}

}
