package com.FoodPlaza.servlate;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.FoodPlaza.dao.CustomerDaoImpl;
import com.FoodPlaza.pojo.Customer;
//import com.FoodPlaza.pojo.Customer;
import com.FoodPlaza.pojo.Feedback;

/**
 * Servlet implementation class CustomerServlet
 */
@WebServlet("/CustomerServlet")
public class CustomerServlet extends HttpServlet {

	Customer cu = new Customer();
	CustomerDaoImpl cd = new CustomerDaoImpl();
	boolean flag=false;
	RequestDispatcher rd;

	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CustomerServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s = request.getSession();
		String operation=request.getParameter("action");

		if(operation!=null && operation.equals("Update"))
		{
			int customerId=Integer.parseInt(request.getParameter("CID"));
			cu=cd.searchCustomer(customerId);

			s.setAttribute("CustomerDetails", cu);
			response.sendRedirect("UpdateCustomer.jsp");
		}
		else if(operation!=null && operation.equals("updateprofile"))
		{
			String emailId=request.getParameter("emailId");
			cu=cd.getCustomerByEmail(emailId);
			s.setAttribute("CustomerDetails", cu);
			response.sendRedirect("UpdateCustomer.jsp");

		}
		else if(operation!=null && operation.equals("Delete")) 
		{
			int customerId=Integer.parseInt(request.getParameter("CID"));
			flag=cd.deleteCustomer(customerId);
			if(flag== true)
			{
				request.setAttribute("Delete","Delete sucessfully");
				rd=request.getRequestDispatcher("Index.jsp");
				rd.forward(request, response);


				/*response.sendRedirect("CustomerServlet");*/
			}

			else
			{
				request.setAttribute("Error", "opps? something went wrong please try again");
				rd=request.getRequestDispatcher("Index.jsp");
				rd.forward(request, response);	

				/*					response.sendRedirect("error.html");
				 */				
				}

		}
		else if(operation!=null && operation.equals("showfeedback")) 
		{
			List<Feedback> flist=cd.ShowFeedback();
			s.setAttribute("FeedbackDetails", flist);
			response.sendRedirect("Feedbacklist.jsp");
		}

		else
		{
			List<Customer>cl=cd.displayCustomer();
			s.setAttribute("CustomerList", cl);
			response.sendRedirect("CustomerList.jsp");
		}
	}



	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Feedback f=new Feedback();

		String operation=request.getParameter("action");
		if(operation!=null && operation.equals("AddCustomer"))
		{
			String CustomerName=request.getParameter("CustomerName");
			String ContectNo=request.getParameter("ContectNo");
			String Email=request.getParameter("Email");
			String cadd=request.getParameter("cadd");
			String Password=request.getParameter("Password");
			cu.setCustomerName(CustomerName);
			cu.setContactNo(ContectNo);
			cu.setEmailId(Email);
			cu.setAddress(cadd);
			cu.setPassword(Password);

			flag=cd.addCustomer(cu);
			if(flag== true)
			{
				request.setAttribute("AddCustomer","Customer Added sucessfully");
				rd=request.getRequestDispatcher("Index.jsp");
				rd.forward(request, response);


				//response.sendRedirect("Sucess.html");
			}
			else
			{
				request.setAttribute("Error", "opps? something went wrong please try again");
				rd=request.getRequestDispatcher("Index.jsp");
				rd.forward(request, response);	
				/*response.sendRedirect("error.html");*/
			}
		}

		else if(operation!=null && operation.equals("UpdateCustomer"))
		{
			String CustomerName=request.getParameter("CustomerName");
			String ContectNo=request.getParameter("ContectNo");
			String Email=request.getParameter("Email");
			String cadd=request.getParameter("cadd");
			String Password=request.getParameter("Password");
			cu.getCustomerId();
			cu.setCustomerName(CustomerName);
			cu.setContactNo(ContectNo);
			cu.setEmailId(Email);
			cu.setAddress(cadd);
			cu.setPassword(Password);

			flag=cd.updateCustomer(cu);
			if(flag== true)
			{
				request.setAttribute("ProfileUpdated","Profile updateed sucessfully");
				rd=request.getRequestDispatcher("Index.jsp");
				rd.forward(request, response);

				/*response.sendRedirect("CustomerServlet");*/
			}
		}
			else if(operation!=null && operation.equals("addfeedback"))
			{
				String Name=request.getParameter("Name");
				String Emailid=request.getParameter("Email");
				long ContactNo=Long.parseLong(request.getParameter("ContectNo"));
				String Comments=request.getParameter("Comments");
				
				f.setName(Name);
				
				f.setContectNo(ContactNo);;
				f.setEmailId(Emailid);
				f.setComments(Comments);
				flag=cd.AddFeedback(f);


				if(flag==true)
				{
					request.setAttribute("feedback", "Feedback added successfully");
					rd=request.getRequestDispatcher("Index.jsp");
					rd.forward(request, response);		
				}
				else
				{
					request.setAttribute("Error", "opps? something went wrong please try again");
					rd=request.getRequestDispatcher("Index.jsp");
					rd.forward(request, response);	
					//response.sendRedirect("error.html");
				}
			}
		}}
			
		
	




