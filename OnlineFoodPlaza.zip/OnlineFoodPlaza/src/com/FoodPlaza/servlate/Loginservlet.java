package com.FoodPlaza.servlate;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.FoodPlaza.dao.LoginDaoImpl;

/**
 * Servlet implementation class Loginservlet
 */
@WebServlet("/Loginservlet")
public class Loginservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	RequestDispatcher rd;
 
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Loginservlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s=request.getSession();
		s.invalidate();
	response.sendRedirect("Index.jsp");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession s=request.getSession();
		PrintWriter p=response.getWriter();
		boolean flag=false;
		LoginDaoImpl ld= new LoginDaoImpl();
	
	String Type=request.getParameter("Type");
	String UserName=request.getParameter("uname");
	String Password=request.getParameter("pass");
	String action = request.getParameter("action");
	String emailId = request.getParameter("emailId");
	String newPassword = request.getParameter("newPassword");
	String oldPassword = request.getParameter("oldPassword");
	
	if(action != null && action.equals("changePassword"))
	{
		flag = ld.adminLogin(emailId, oldPassword);
				if(flag == true)
				{
					ld.changePassword(emailId, newPassword);
				}
				else
				{
					response.sendRedirect("ChangePassword.jsp");
				}
	}
	else if(Type.equals("Customer"))
	{
		flag= ld.customerLogin(UserName, Password);
		if(flag==true)
		{
			s.setAttribute("cname",UserName);
			p.println("<script type=\"text/javascript\">");
			p.println("alert('Customer Login successfully');");
			p.println("location='Index.jsp';");
			p.println("</script>");
			//response.sendRedirect("Index.jsp");
		}
		else
		{
			request.setAttribute("Error", "opps? something went wrong please try again");
			rd=request.getRequestDispatcher("Index.jsp");
			rd.forward(request, response);
/*			response.sendRedirect("error..html");
*/		}
	}
		
		else if(Type.equals("Admin"))
		{
			flag= ld.adminLogin(UserName, Password);
			
			if(flag==true)
			{
				s.setAttribute("adminname",UserName);
				p.println("<script type=\"text/javascript\">");
				p.println("alert('Admin Login successfully');");
				p.println("location='Index.jsp';");
				p.println("</script>");
				
				/*s.setAttribute("adminname",UserName);
				response.sendRedirect("Index.jsp");*/
			}
			else
			{
				request.setAttribute("Error", "opps? something went wrong please try again");
				rd=request.getRequestDispatcher("Index.jsp");
				rd.forward(request, response);
/*				response.sendRedirect("error..html");
*/			}
		}
		
		
		
		
	}
	
	}


