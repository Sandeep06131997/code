package com.FoodPlaza.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.FoodPlaza.pojo.Food;
import com.FoodPlaza.utility.DatabaseConnection;

public class FoodDaoImpl implements FoodDao {
	Connection c;
	String sql;
	PreparedStatement ps;
	ResultSet rs;

	@Override
	public boolean addFood(Food f) {
		// TODO Auto-generated method stub

		try {
			c = DatabaseConnection.establishConnection();
			sql = "insert into Food_21768(foodName,foodPrice,foodCategory,FoodImage) values(?,?,?,?)";
			ps = c.prepareStatement(sql);
			ps.setString(1, f.getFoodName());
			ps.setDouble(2, f.getFoodPrice());
			ps.setString(3, f.getFoodCategory());
			System.out.println(f.getFoodImage());
			ps.setBlob(4, f.getFoodImage());
			int x = ps.executeUpdate();
			if (x > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public boolean updateFood(Food f) {
		// TODO Auto-generated method stub
		try {
			c = DatabaseConnection.establishConnection();
			sql = "update Food_21768 set foodName=?,foodPrice=?,foodCategory=? where foodId=?";
			ps = c.prepareStatement(sql);
			ps.setString(1, f.getFoodName());
			ps.setDouble(2, f.getFoodPrice());
			ps.setString(3, f.getFoodCategory());
			ps.setInt(4, f.getFoodId());
			int x = ps.executeUpdate();
			if (x > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public boolean deleteFood(int foodId) {
		// TODO Auto-generated method stub
		try {

			c = DatabaseConnection.establishConnection();
			sql = "delete from Food_21768 where foodId=?";
			ps = c.prepareStatement(sql);
			ps.setInt(1, foodId);
			int x = ps.executeUpdate();
			if (x > 0) {
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

		return false;
	}

	@Override
	public List<Food> displayFood() {
		// TODO Auto-generated method stub

		List<Food> Foodlist = new ArrayList<Food>();
		try {
			c = DatabaseConnection.establishConnection();
			sql = "Select * from Food_21768";
			ps = c.prepareStatement(sql);
			rs = ps.executeQuery();
			while (rs.next()) {
				Food f = new Food();
				f.setFoodId(rs.getInt("foodId"));
				f.setFoodName(rs.getString("foodName"));
				f.setFoodPrice(rs.getDouble("foodPrice"));
				f.setFoodCategory(rs.getString("foodCategory"));
				Foodlist.add(f);

			}
			return Foodlist;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public Food searchFood(int foodId) {
		// TODO Auto-generated method stub
		Food f = new Food();
		try {
			c = DatabaseConnection.establishConnection();
			sql = "Select * from Food_21768 where foodId=?";
			ps = c.prepareStatement(sql);

			ps.setInt(1, foodId);
			rs = ps.executeQuery();
			if (rs.next()) {

				f.setFoodId(rs.getInt("foodId"));
				f.setFoodName(rs.getString("foodName"));
				f.setFoodPrice(rs.getDouble("foodPrice"));
				f.setFoodCategory(rs.getString("foodCategory"));
				f.setFoodImage(rs.getBinaryStream("FoodImage"));

			}
			return f;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;
	}

	@Override
	public List<Food> searchFoodByName(String name) {

		List<Food> flist= new ArrayList<Food>();
		try {
			c = DatabaseConnection.establishConnection();
			sql="Select * from Food_21768 where foodname like ?";
			
			ps=c.prepareStatement(sql);
			ps.setString(1, '%'+name+'%');
			rs=ps.executeQuery();
			while(rs.next())
			{
				Food f = new Food();
				f.setFoodId(rs.getInt("foodId"));
				f.setFoodName(rs.getString("foodName"));
				f.setFoodPrice(rs.getDouble("foodPrice"));
				f.setFoodCategory(rs.getString("foodCategory"));
				flist.add(f);

			}
			return flist;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}

}
