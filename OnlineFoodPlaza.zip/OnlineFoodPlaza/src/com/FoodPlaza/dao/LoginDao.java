package com.FoodPlaza.dao;

public interface LoginDao
{
boolean customerLogin(String emailId, String password);
boolean adminLogin(String emailId, String password);
boolean changePassword(String adminName,String newpass);
}
