package com.FoodPlaza.dao;



import java.util.List;

import com.FoodPlaza.pojo.Food;

public interface FoodDao {
boolean addFood(Food f);
boolean updateFood(Food f);
boolean deleteFood(int foodId);
List<Food> displayFood();
Food searchFood(int foodId);
List<Food>searchFoodByName(String name);


}
