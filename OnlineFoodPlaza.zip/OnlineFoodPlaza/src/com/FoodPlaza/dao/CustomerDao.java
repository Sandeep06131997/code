package com.FoodPlaza.dao;

import java.util.List;

import com.FoodPlaza.pojo.Customer;
import com.FoodPlaza.pojo.Feedback;


public interface CustomerDao {
	
	boolean addCustomer(Customer cu);
	boolean updateCustomer(Customer cu);
	boolean deleteCustomer(int customerId);
	List<Customer> displayCustomer();
	Customer searchCustomer(int customerId);
	Customer getCustomerByEmail(String email);
	boolean AddFeedback(Feedback f);
	List<Feedback> ShowFeedback();



}
