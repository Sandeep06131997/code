package com.FoodPlaza.dao;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.FoodPlaza.utility.DatabaseConnection;
import com.mysql.jdbc.Connection;

public class LoginDaoImpl implements LoginDao
{
	java.sql.Connection c;
	String sql;
	PreparedStatement ps;
	ResultSet rs;
	@Override
	public boolean customerLogin(String emailId, String password) {
		// TODO Auto-generated method stub
		try
		{
			c = DatabaseConnection.establishConnection();		
			sql = "select  emailId, password from Customer_21768 where emailId=? and password = ?";
			ps = c.prepareStatement(sql);
			ps.setString(1, emailId);;
			ps.setString(2, password);
			rs = ps.executeQuery();
			if(rs.next())
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean adminLogin(String emailId, String password) {
		// TODO Auto-generated method stub
		try
		{
			c = DatabaseConnection.establishConnection();
			sql = "select emailId, password from Admin_21768 where emailId=? and password=?";
			ps = c.prepareStatement(sql);
			ps.setString(1, emailId);
			ps.setString(2, password);
			rs = ps.executeQuery();
			if(rs.next())
			{
				return true;
			}
			else
			{
				return false;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
	}

	@Override
	public boolean changePassword(String adminName, String newpass) {
		// TODO Auto-generated method stub
		try
		{
		c = DatabaseConnection.establishConnection();
		sql = "update Admin_21768 set Password=? where emailId=?";
		ps = c.prepareStatement(sql);
		ps.setString(1, newpass);
		ps.setString(2, adminName);
		int x = ps.executeUpdate();
		if(x>0)
		{
			return true;
		}
		else
		{
			return false;
		}
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return false;
		
	}
	
}
