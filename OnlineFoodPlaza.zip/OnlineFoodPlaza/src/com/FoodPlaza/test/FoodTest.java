package com.FoodPlaza.test;
import java.util.List;
import java.util.Scanner;

import com.FoodPlaza.dao.FoodDaoImpl;
import com.FoodPlaza.pojo.Food;

public class FoodTest {
	static Scanner sc = new Scanner(System.in);
public static void main(String[] args) {
	boolean result;
	Food f = new Food();
	FoodDaoImpl fd = new FoodDaoImpl();
	System.out.println("1.Add Food :-");
	System.out.println("2.Update Food :-");
	System.out.println("3.Delete Food :-");
	System.out.println("4.Display Food :-");
	System.out.println("5.Search Food :-");
	System.out.println("Enter choice :-");
	int ch =sc.nextInt();
	switch(ch)
	{
	case 1 :
		System.out.println("Enter Food Name :-");
		String fname=sc.next();
		System.out.println("Enter Price");
		double price=sc.nextDouble();
		System.out.println("Enter Category");
		String category=sc.next();
		f.setFoodName(fname);
		f.setFoodPrice(price);
		f.setFoodCategory(category);
		result=fd.addFood(f);
		if(result==true)
		{
			System.out.println("FOOD ADDED SUCCESSFULLY");
		}
		else
		{
			System.out.println("not added");
		}
		break;
	case 2 :
		System.out.println("Enter Food Id To Update :-");
		int id=sc.nextInt();
		System.out.println("Enter Food Name :-");
	 fname=sc.next();
		System.out.println("Enter Price");
 price=sc.nextDouble();
		System.out.println("Enter Category");
		category=sc.next();
		f.setFoodName(fname);
		f.setFoodPrice(price);
		f.setFoodCategory(category);
		f.setFoodId(id);
		result =fd.updateFood(f);
		if(result==true)
		{
			System.out.println("FOOD UPDATED SUCCESSFULLY");
		}
		else
		{
			System.out.println("not updated");
		}
		break;
	case 3 :
		System.out.println("Enter Id To Delete :-");
		id=sc.nextInt();
		result=fd.deleteFood(id);
		if(result==true)
		{
			System.out.println("FOOD DELETED SUCCESSFULLY");
		}
		else
		{
			System.out.println("not deleted");
		}
		
		break;
	case 4 :
		System.out.println("Food details are :- ");
		List<Food> flist=fd.displayFood();
		
		for(Food f1:flist)
		{
			System.out.println(f1);
		}
		break;
	case 5 :
		System.out.println("Enter Food Id :-");
		int foodId=sc.nextInt();
		f = fd.searchFood(foodId);
		System.out.println(f);
		
		break;
	}
	
	
}
}
