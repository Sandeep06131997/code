package com.FoodPlaza.test;
import java.util.List;
import java.util.Scanner;

import com.FoodPlaza.dao.CartDaoImpl;
import com.FoodPlaza.dao.OrderDaoImpl;
import com.FoodPlaza.pojo.Cart;
import com.FoodPlaza.pojo.Order;


public class CartTest {
	public static void main(String[] args) {
		
	
	Cart ca = new Cart();
	Order oi = new Order();
	Scanner sc = new Scanner(System.in);
	CartDaoImpl ci = new CartDaoImpl();
	OrderDaoImpl od = new OrderDaoImpl();
	boolean result;
	System.out.println("1.Add to Cart");
	System.out.println("2.Show Cart");
	System.out.println("3.Delete Cart");
	System.out.println("4.Place Order");
	System.out.println("5.Show Order");
	System.out.println("Enter Choice");
	int c = sc.nextInt();
	switch (c) 
	{
	case 1:
		System.out.println("Enter Food Id");
		int foodId = sc.nextInt();
		System.out.println("Enter Email Id");
		String emailId = sc.next();
		System.out.println("Enter Quantity");
		int quantity = sc.nextInt();

		ca.setFoodId(foodId);
		ca.setEmailId(emailId);
		ca.setQuantity(quantity);

		result = ci.addToCart(ca);
		if (result == true)
		{
			System.out.println("Added Succesfully");
		} 
		else 
		{
			System.out.println("Not Added");
		}
		break;
	case 2:
		System.out.println("Enter Email Id");
		emailId = sc.next();
		List<Cart> CartList = ci.showCart(emailId);
		for (Cart cc : CartList)
		{
			System.out.println(cc);
		}
		break;
	case 3:
		System.out.println("Emter Cart Id  to Delete");
		int cartId = sc.nextInt();
		result = ci.deleteCart(cartId);
		if (result == true)
		{
			System.out.println("Cart Deleted");
		}
		else 
		{
			System.out.println("Not Deleted");
		}
		break;
	case 4:
		System.out.println("Enter  email id to place order");
		emailId = sc.next();
		boolean flag = od.placeOrder(emailId);
		if (flag == true) 
		{
			System.out.println("Order Placed");
		}
		else 
		{
			System.out.println("Order Not placed");
		}
		break;
	case 5:
		System.out.println("Enter Email Id");
		emailId = sc.next();
		List<Order> OrderList = od.showOrder();
		for (Order oo : OrderList)
		{
			System.out.println(oo);
		}

	}


	

}
}
